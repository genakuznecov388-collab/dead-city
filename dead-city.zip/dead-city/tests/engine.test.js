'use strict';
// Тесты движка: карта, волны, урон, перки, смерть, лидерборд.
const test = require('node:test');
const assert = require('node:assert');
const os = require('node:os');
const path = require('node:path');
const fs = require('node:fs');

process.env.SCORES_FILE = path.join(os.tmpdir(), 'dc-test-scores-' + process.pid + '.json');
process.env.ORDERS_FILE = path.join(os.tmpdir(), 'dc-test-orders-' + process.pid + '.json');
process.env.PERKS_FILE = path.join(os.tmpdir(), 'dc-test-perks-' + process.pid + '.json');

const { Game, generateMap, circleFree, W, H } = require('../server/game');
const MAP = require('../server/map');
const C = require('../server/content');
const store = require('../server/store');
const shop = require('../server/shop');
const { makeRng } = require('../server/rng');

test('карта: генерируется, есть проходимая площадь, старт свободен', () => {
  for (const id of Object.keys(C.LOCATIONS)) {
    const g = new Game({ code: 'TEST', location: id, seed: 12345, mode: 'solo' });
    let floors = 0;
    for (let i = 0; i < g.map.length; i++) if (g.map[i] === 0) floors++;
    assert.ok(floors > g.map.length * 0.35, id + ': слишком мало свободного места');
    assert.ok(circleFree(g.map, W / 2, H / 2, 14), id + ': центр застроен');
    assert.strictEqual(g.map.length, 48 * 36, 'размер сетки карты');
  }
});

test('игрок: вход, старт волны, спавн зомби, снапшот', () => {
  const g = new Game({ code: 'T1', location: 'suburb', seed: 777, mode: 'solo' });
  const p = g.addPlayer('sock1', 'Тестер', 'soldier');
  assert.strictEqual(p.hp, C.CLASSES.soldier.hp);
  assert.strictEqual(g.phase, 'lobby');
  assert.ok(g.start());
  assert.strictEqual(g.phase, 'break');

  for (let i = 0; i < 200; i++) g.tick(50); // 10 секунд
  assert.strictEqual(g.phase, 'active', 'волна должна начаться');
  assert.strictEqual(g.wave, 1);
  assert.ok(g.zombies.length > 0, 'зомби должны появиться');

  const snap = g.snapshot();
  assert.strictEqual(snap.players.length, 1);
  assert.ok(snap.zombies.length === g.zombies.length);
  assert.strictEqual(snap.wave, 1);
  assert.ok(snap.players[0].hp > 0);
  assert.strictEqual(snap.mapW, W);
});

test('волны: со временем зомби становится больше и они злее', () => {
  const g = new Game({ code: 'T2', location: 'factory', seed: 4242, mode: 'solo' });
  g.addPlayer('a', 'A', 'soldier');
  g.start();
  for (let i = 0; i < 200; i++) g.tick(50);
  const countW1 = g.zombies.length + g.spawnQueue.length;
  g.wave = 9;
  g.startWave();
  const countW10 = g.zombies.length + g.spawnQueue.length;
  assert.ok(countW10 > countW1, 'на 10-й волне врагов должно быть больше');
  assert.ok(g.spawnQueue.indexOf('boss') >= 0, 'каждая 5-я волна — с боссом');
});

test('урон и смерть зомби: начисляются очки и опыт, возможен лут', () => {
  const g = new Game({ code: 'T3', location: 'suburb', seed: 99, mode: 'solo' });
  const p = g.addPlayer('a', 'A', 'soldier');
  g.wave = 1;
  g.phase = 'active';
  g.spawnZombie('walker');
  const z = g.zombies[0];
  const hp0 = z.hp;
  g.damageZombie(z, 5, p, 0, 0);
  assert.ok(z.hp < hp0, 'зомби должен получать урон');
  g.damageZombie(z, 999, p, 0, 0);
  assert.strictEqual(g.zombies.length, 0, 'зомби должен умереть');
  assert.strictEqual(p.kills, 1);
  assert.ok(p.score > 0, 'очки начисляются');
  assert.ok(p.xp > 0, 'опыт начисляется');
});

test('перки: уровень даёт выбор из трёх, выбор применяется', () => {
  const g = new Game({ code: 'T4', location: 'suburb', seed: 5, mode: 'solo' });
  const p = g.addPlayer('a', 'A', 'student');
  p.xp = 500;
  g.grantLevels(p);
  assert.ok(p.level > 1, 'уровень должен вырасти');
  assert.ok(p.offer && p.offer.options.length === 3, 'предлагается 3 перка');
  const opt = p.offer.options[0];
  const before = p.maxHp;
  const ok = g.choosePerk('a', opt.id);
  assert.ok(ok, 'выбор перка принят');
  assert.ok(p.perks.length === 1);
  assert.ok(p.offer === null || p.offer !== undefined);
  assert.ok(p.maxHp >= before);
  // повторный выбор того же перка недоступен
  const again = p.offer ? p.offer.options.find((o) => o.id === opt.id) : undefined;
  assert.strictEqual(again, undefined);
});

test('заражение: укус повышает заражение, аптечка снижает', () => {
  const g = new Game({ code: 'T5', location: 'hospital', seed: 31, mode: 'solo' });
  const p = g.addPlayer('a', 'A', 'fireman');
  p.spawnProt = 0;
  g.damagePlayer(p, 5, 20);
  assert.ok(p.inf > 0, 'заражение выросло');
  p.hp = 50;
  g.dropLoot(p.x, p.y, 1);
  // кладём аптечку прямо под игрока
  g.loot = [{ id: 1, x: p.x, y: p.y, type: 'medkit' }];
  const hpBefore = p.hp;
  g.pickup(p);
  assert.ok(p.hp > hpBefore, 'аптечка лечит');
  assert.ok(p.inf < 20, 'аптечка снижает заражение');
});

test('смерть игрока: в одиночку — сразу, в кооперативе — отключка с шансом на подъём', () => {
  const solo = new Game({ code: 'S', location: 'suburb', seed: 8, mode: 'solo' });
  const sp = solo.addPlayer('a', 'A', 'police');
  let died = null;
  solo.onDeath = (pl) => { died = pl; };
  sp.spawnProt = 0;
  solo.damagePlayer(sp, 9999, 0);
  assert.ok(sp.dead, 'в одиночном режиме смерть окончательная');
  assert.strictEqual(died, sp, 'результат ушёл на сервер');

  const coop = new Game({ code: 'C', location: 'suburb', seed: 9, mode: 'coop' });
  const p1 = coop.addPlayer('a', 'A', 'soldier');
  coop.addPlayer('b', 'B', 'student');
  p1.spawnProt = 0;
  coop.damagePlayer(p1, 9999, 0);
  assert.ok(!p1.dead && p1.downed > 0, 'в кооперативе игрок в отключке');

  // товарищ поднимает
  const p2 = coop.players.get('b');
  p2.x = p1.x; p2.y = p1.y;
  p2.input.revive = true;
  for (let i = 0; i < 100; i++) coop.tick(50);
  assert.strictEqual(p1.downed, 0, 'товарища подняли');
  assert.ok(p1.hp > 0);
});

test('лидерборд: топ-50, сортировка, место', () => {
  const file = process.env.SCORES_FILE;
  if (fs.existsSync(file)) fs.unlinkSync(file);
  for (let i = 0; i < 60; i++) {
    store.addScore({ nick: 'Игрок' + i, score: i * 100, kills: i, wave: 1 + i, level: 1, cls: 'soldier', location: 'suburb', mode: 'solo' });
  }
  const top = store.top(50);
  assert.strictEqual(top.length, 50, 'ровно 50 строк');
  assert.strictEqual(top[0].score, 5900, 'первый — с максимальным счётом');
  assert.ok(top[0].score >= top[49].score, 'отсортировано по убыванию');
  const res = store.addScore({ nick: 'Новичок', score: 10, kills: 0, wave: 1, level: 1, cls: 'soldier', location: 'suburb', mode: 'coop' });
  assert.strictEqual(res.rank, 60, 'место считается по всему списку (59 игроков с большим счётом)');
  assert.strictEqual(res.inTop, false);
});

test('ник: обрезается, чистится от разметки', () => {
  const dirty = store.sanitizeNick('<script>alert(1)</script>');
  assert.ok(!/[<>&"'`\\/]/.test(dirty), 'в нике не остаётся разметки: ' + dirty);
  assert.ok(dirty.length <= 16);
  assert.strictEqual(store.sanitizeNick('  Вася   Пупкин  '), 'Вася Пупкин');
  assert.strictEqual(store.sanitizeNick(''), 'Безымянный');
  assert.ok(store.sanitizeNick('A'.repeat(50)).length <= 16);
});

test('сид: одинаковый сид даёт одинаковую карту', () => {
  const a = generateMap(C.LOCATIONS.mall, makeRng(2024));
  const b = generateMap(C.LOCATIONS.mall, makeRng(2024));
  assert.deepStrictEqual([...a.map], [...b.map], 'карта детерминирована по сиду');
  assert.deepStrictEqual([...a.floor], [...b.floor], 'полы детерминированы по сиду');
  assert.strictEqual(a.decor.length, b.decor.length, 'декор детерминирован по сиду');
});

test('контент: 6 классов и 5 локаций с ростом сложности', () => {
  assert.strictEqual(Object.keys(C.CLASSES).length, 6, 'солдат, пожарник, полиция, студент, строитель, спортсмен');
  assert.ok(C.CLASSES.athlete, 'класс «Спортсмен» есть');
  assert.strictEqual(C.CLASSES.athlete.ability.id, 'dash');
  assert.strictEqual(Object.keys(C.LOCATIONS).length, 5);
  const diffs = Object.values(C.LOCATIONS).map((l) => l.diff);
  assert.deepStrictEqual(diffs, [1, 2, 3, 4, 5]);
  const muls = Object.values(C.LOCATIONS).map((l) => l.mul);
  for (let i = 1; i < muls.length; i++) assert.ok(muls[i] > muls[i - 1], 'множитель очков растёт с сложностью');
  for (const c of Object.values(C.CLASSES)) {
    assert.ok(c.ability && c.ability.id, 'у класса есть способность');
    assert.ok(C.WEAPONS[c.weapon], 'оружие класса существует');
  }
  for (const l of Object.values(C.LOCATIONS)) {
    assert.ok(l.palette && l.palette.f1 && l.palette.accent, 'у локации есть своя палитра');
    assert.ok(l.layout, 'у локации есть тип планировки');
  }
  assert.ok(C.TIPS.length >= 8);
  assert.ok(C.TIPS.some((t) => t.indexOf('Airon') >= 0), 'в советах есть упоминание автора');
});

test('карты: у каждой локации свой вид — дороги, полы и декор', () => {
  const styles = new Set();
  for (const id of Object.keys(C.LOCATIONS)) {
    const gen = MAP.generateMap(C.LOCATIONS[id], makeRng(777 + id.length));
    assert.strictEqual(gen.map.length, 48 * 36);
    assert.strictEqual(gen.floor.length, 48 * 36);
    assert.ok(gen.decor.length > 30, id + ': должен быть декор (' + gen.decor.length + ')');
    const floors = new Set();
    for (const f of gen.floor) floors.add(f);
    const codes = new Set();
    for (const c of gen.map) codes.add(c);
    assert.ok(floors.size >= 2, id + ': пол должен быть разнообразным');
    assert.ok(codes.size >= 2, id + ': на карте должны быть разные препятствия');
    styles.add([...floors].sort().join(',') + '|' + [...codes].sort().join(','));
    // стартовая зона свободна
    assert.ok(circleFree(gen.map, W / 2, H / 2, 40), id + ': центр карты занят');
  }
  assert.ok(styles.size >= 5, 'все локации различаются видом: ' + styles.size);
});

test('спавн: зомби никогда не появляется внутри препятствия', () => {
  for (const id of Object.keys(C.LOCATIONS)) {
    const g = new Game({ code: 'SPAWN', location: id, seed: 31337, mode: 'solo' });
    g.addPlayer('a', 'A', 'soldier');
    g.start();
    for (let i = 0; i < 200; i++) g.tick(50);
    for (let w = 0; w < 3; w++) {
      g.startWave();
      for (let i = 0; i < 60; i++) g.tick(50);
    }
    assert.ok(g.zombies.length > 0, id + ': зомби должны появиться');
    for (const z of g.zombies) {
      assert.ok(circleFree(g.map, z.x, z.y, z.r - 1), id + ': зомби ' + z.type + ' застрял в препятствии');
      const cx = Math.floor(z.x / MAP.TILE), cy = Math.floor(z.y / MAP.TILE);
      assert.strictEqual(g.map[cy * MAP.COLS + cx], 0, id + ': центр зомби стоит на твёрдом тайле');
    }
  }
});

test('умные зомби: обходят препятствие, а не упираются в него', () => {
  const g = new Game({ code: 'NAV', location: 'mall', seed: 909, mode: 'solo' });
  const p = g.addPlayer('a', 'A', 'soldier');
  g.wave = 1;
  g.phase = 'active';
  // ставим игрока и зомби по разные стороны от колонны
  const T = MAP.TILE;
  const cx = 20, cy = 18;
  p.x = (cx + 4) * T + T / 2; p.y = cy * T + T / 2;
  g.map[cy * MAP.COLS + cx] = MAP.O.WALL; // препятствие между ними
  g.spawnZombie('walker');
  const z = g.zombies[g.zombies.length - 1];
  z.x = (cx - 4) * T + T / 2; z.y = cy * T + T / 2;
  const startX = z.x;
  g.buildFlow();
  let blockedAtWall = 0;
  for (let i = 0; i < 240; i++) {
    g.tick(50);
    const tcx = Math.floor(z.x / T), tcy = Math.floor(z.y / T);
    if (g.map[tcy * MAP.COLS + tcx] !== 0) blockedAtWall++;
  }
  assert.strictEqual(blockedAtWall, 0, 'зомби ни разу не оказался внутри препятствия');
  assert.ok(z.x > startX + 30, 'зомби сдвинулся в сторону игрока: ' + Math.round(startX) + ' → ' + Math.round(z.x));
  // через 12 секунд он должен быть уже у игрока (обошёл колонну) либо близко
  assert.ok(Math.hypot(z.x - p.x, z.y - p.y) < 260, 'зомби обошёл препятствие и подошёл близко');
});

test('спортсмен: рывок двигает героя и даёт неуязвимость', () => {
  const g = new Game({ code: 'DASH', location: 'suburb', seed: 55, mode: 'solo' });
  const p = g.addPlayer('a', 'A', 'athlete');
  p.spawnProt = 0;
  g.wave = 1; g.phase = 'active';
  p.ang = 0;
  const x0 = p.x, y0 = p.y;
  g.useAbility('a');
  assert.strictEqual(p.immune > 0, true, 'включилась неуязвимость');
  const hp0 = p.hp;
  g.damagePlayer(p, 50, 10);
  assert.strictEqual(p.hp, hp0, 'во время неуязвимости урон не проходит');
  for (let i = 0; i < 12; i++) g.tick(50);
  assert.ok(Math.hypot(p.x - x0, p.y - y0) > 100, 'герой переместился рывком');
  assert.ok(p.abilityCd > 0, 'способность ушла в перезарядку');
});

test('магазин: цены по уровням, заявка и выдача перка после подтверждения', () => {
  assert.strictEqual(shop.priceFor(1), 10);
  assert.strictEqual(shop.priceFor(2), 20);
  assert.strictEqual(shop.priceFor(5), 50);
  const cat = shop.catalog();
  assert.strictEqual(cat.perks.length, 12, 'в магазине все 12 перков');
  assert.strictEqual(cat.doubleXp.price, 20);
  assert.ok(cat.card.number.replace(/\s/g, '').length === 16, 'номер карты из 16 цифр');

  const nick = 'Тест Донат';
  const o1 = shop.createOrder({ nick, kind: 'perk', perkId: 'damage', level: 2 });
  assert.ok(o1.order && o1.order.amount === 20, 'цена второго уровня — 20 ₽');
  let st = shop.playerState(nick);
  assert.strictEqual(st.orders.filter((o) => o.status === 'pending').length, 1);
  assert.strictEqual(st.perks.damage || 0, 0, 'до подтверждения перк не выдан');

  const out = shop.decide(o1.order.id, 'paid');
  assert.ok(!out.error, 'заявка подтверждена');
  st = shop.playerState(nick);
  assert.strictEqual(st.perks.damage, 2, 'выдан перк 2-го уровня');

  const o2 = shop.createOrder({ nick, kind: 'xpx2' });
  shop.decide(o2.order.id, 'paid');
  assert.strictEqual(shop.playerState(nick).xp2, true, 'двойной опыт включён');
  assert.ok(shop.decide(o2.order.id, 'paid').error, 'повторно заявку не подтвердить');
});

test('донат-перки работают в бою и переносятся на любой класс', () => {
  const nick = 'Донатер';
  const o = shop.createOrder({ nick, kind: 'perk', perkId: 'tough', level: 3 });
  shop.decide(o.order.id, 'paid');
  const o2 = shop.createOrder({ nick, kind: 'xpx2' });
  shop.decide(o2.order.id, 'paid');

  const g = new Game({ code: 'DON', location: 'suburb', seed: 3, mode: 'solo' });
  const p = g.addPlayer('a', nick, 'student', shop.permanentFor(nick));
  assert.strictEqual(p.maxHp, C.CLASSES.student.hp + 75, '+25 HP за каждый из 3 уровней');
  assert.strictEqual(p.st.xp, C.CLASSES.student.xp * 2, 'двойной опыт применён');
  const plain = g.addPlayer('b', 'БезДоната', 'student', shop.permanentFor('БезДоната'));
  assert.strictEqual(plain.maxHp, C.CLASSES.student.hp, 'без доната бонусов нет');
});
