'use strict';
// Сквозной сетевой тест: два игрока в одной комнате (как два браузера).
// Использует встроенный в Node WebSocket и протокол Engine.IO — без новых зависимостей.
const test = require('node:test');
const assert = require('node:assert');
const { spawn } = require('node:child_process');
const os = require('node:os');
const path = require('node:path');
const fs = require('node:fs');

const PORT = 3131;
const BASE = 'http://127.0.0.1:' + PORT;
const SCORES = path.join(os.tmpdir(), 'dc-e2e-scores-' + process.pid + '.json');
const ORDERS = path.join(os.tmpdir(), 'dc-e2e-orders-' + process.pid + '.json');
const PERKS = path.join(os.tmpdir(), 'dc-e2e-perks-' + process.pid + '.json');

let child;

function wait(ms) { return new Promise((r) => setTimeout(r, ms)); }

async function until(fn, timeout = 8000, step = 120) {
  const t0 = Date.now();
  for (;;) {
    const v = await fn();
    if (v) return v;
    if (Date.now() - t0 > timeout) throw new Error('таймаут ожидания условия');
    await wait(step);
  }
}

// Минимальный клиент Socket.IO v4 поверх WebSocket.
function connect() {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(`ws://127.0.0.1:${PORT}/socket.io/?EIO=4&transport=websocket`);
    const handlers = {};
    const log = [];
    const api = {
      ws, log,
      on(ev, fn) { (handlers[ev] = handlers[ev] || []).push(fn); },
      last(ev) { for (let i = log.length - 1; i >= 0; i--) if (log[i].ev === ev) return log[i].data; return null; },
      count(ev) { return log.filter((x) => x.ev === ev).length; },
      emit(ev, data) { ws.send('42' + JSON.stringify([ev, data])); },
      close() { try { ws.close(); } catch (e) { /* уже закрыт */ } },
    };
    const timer = setTimeout(() => reject(new Error('нет соединения с сервером')), 10000);
    ws.addEventListener('message', (msg) => {
      const raw = String(msg.data);
      for (const frame of raw.split('\x1e')) {
        if (!frame) continue;
        const t = frame[0];
        if (t === '0') { ws.send('40'); continue; }         // handshake
        if (t === '2') { ws.send('3'); continue; }          // ping → pong
        if (t === '4' && frame[1] === '0') { clearTimeout(timer); resolve(api); continue; }
        if (t === '4' && frame[1] === '2') {
          try {
            const [ev, data] = JSON.parse(frame.slice(2));
            log.push({ ev, data });
            (handlers[ev] || []).forEach((fn) => fn(data));
          } catch (e) { /* служебный кадр */ }
        }
      }
    });
    ws.addEventListener('error', () => { clearTimeout(timer); reject(new Error('ошибка WebSocket')); });
  });
}

test.before(async () => {
  if (fs.existsSync(SCORES)) fs.unlinkSync(SCORES);
  child = spawn(process.execPath, ['server.js'], {
    cwd: path.join(__dirname, '..'),
    env: Object.assign({}, process.env, { PORT: String(PORT), SCORES_FILE: SCORES, ORDERS_FILE: ORDERS, PERKS_FILE: PERKS }),
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  child.stderr.on('data', (d) => process.stderr.write('[server] ' + d));
  await until(async () => {
    try { const r = await fetch(BASE + '/healthz'); return r.ok; } catch (e) { return false; }
  }, 15000, 200);
});

test.after(() => { if (child) child.kill(); });

test('API: контент, статистика, лидеры', async () => {
  const c = await (await fetch(BASE + '/api/content')).json();
  assert.strictEqual(Object.keys(c.classes).length, 6);
  assert.ok(c.classes.athlete, 'класс «Спортсмен» доступен на сервере');
  assert.strictEqual(Object.keys(c.locations).length, 5);
  assert.ok(c.tips.some((t) => t.includes('Airon')));
  const s = await (await fetch(BASE + '/api/stats')).json();
  assert.ok(typeof s.online === 'number');
  const lb = await (await fetch(BASE + '/api/leaderboard')).json();
  assert.ok(Array.isArray(lb.top));
  const shop = await (await fetch(BASE + '/api/shop')).json();
  assert.strictEqual(shop.perks.length, 12, 'в магазине 12 перков');
  assert.strictEqual(shop.doubleXp.price, 20);
  assert.ok(shop.card.number.replace(/\s/g, '').length === 16);
});

test('магазин по сети: заявка создаётся и сохраняется', async () => {
  const r = await fetch(BASE + '/api/shop/order', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ nick: 'СетевойТест', kind: 'perk', perkId: 'speed', level: 1 }),
  });
  const d = await r.json();
  assert.ok(r.ok && d.order, 'заявка принята');
  assert.strictEqual(d.order.amount, 10, 'первый уровень — 10 ₽');
  assert.strictEqual(d.order.status, 'pending');
  const my = await (await fetch(BASE + '/api/shop/my?nick=' + encodeURIComponent('СетевойТест'))).json();
  assert.strictEqual(my.orders.length, 1);
  assert.strictEqual(my.perks.speed || 0, 0, 'до подтверждения перк не выдан');
});

test('двое игроков видят друг друга в одной комнате и начинают рейд', async () => {
  const A = await connect();
  const B = await connect();

  A.emit('hello', { nick: 'Аня', cls: 'soldier', location: 'suburb', mode: 'coop' });
  const joinedA = await until(async () => A.last('joined'));
  assert.ok(joinedA.code && joinedA.code.length === 4, 'комната имеет код');
  assert.strictEqual(joinedA.mode, 'coop');
  assert.ok(Array.isArray(joinedA.map) && joinedA.map.length === 36, 'карта передана строками');
  assert.strictEqual(joinedA.map[0].length, 48);

  B.emit('hello', { nick: 'Боря', cls: 'builder', location: 'suburb', mode: 'coop', code: joinedA.code });
  const joinedB = await until(async () => B.last('joined'));
  assert.strictEqual(joinedB.code, joinedA.code, 'второй игрок попал в ту же комнату');
  assert.strictEqual(joinedB.isHost, false);

  const snap = await until(async () => {
    const s = A.last('snap');
    return s && s.players.length === 2 ? s : null;
  });
  const nicks = snap.players.map((p) => p.nick).sort();
  assert.deepStrictEqual(nicks, ['Аня', 'Боря'], 'оба игрока в снапшоте');

  // онлайн-счётчик
  const stats = await until(async () => {
    const s = await (await fetch(BASE + '/api/stats')).json();
    return s.online >= 2 ? s : null;
  });
  assert.ok(stats.online >= 2, 'счётчик онлайна учитывает обоих');
  assert.ok(stats.rooms >= 1);

  // хозяин начинает рейд
  A.emit('start', {});
  await until(async () => A.last('started') && B.last('started'));

  // ждём волну и зомби
  const withZombies = await until(async () => {
    const s = A.last('snap');
    return s && s.phase === 'active' && s.zombies.length > 0 ? s : null;
  }, 20000);
  assert.ok(withZombies.wave >= 1, 'волна началась');
  assert.ok(withZombies.zombies[0].t, 'у зомби есть тип');

  A.close(); B.close();
});

test('движение игрока доходит до сервера (ввод → снапшот)', async () => {
  const C = await connect();
  C.emit('hello', { nick: 'Ходок', cls: 'police', location: 'suburb', mode: 'solo' });
  const j = await until(async () => C.last('joined'));
  assert.strictEqual(j.mode, 'solo');
  assert.ok(j.isHost, 'в одиночном режиме игрок — хозяин');

  const start = await until(async () => {
    const s = C.last('snap');
    return s && s.players[0] ? { x: s.players[0].x, y: s.players[0].y } : null;
  });

  // Пробуем все четыре направления по очереди: карта процедурная, где-то путь свободен.
  const dirs = ['right', 'down', 'left', 'up'];
  let moved = 0;
  for (const d of dirs) {
    const inp = { ax: start.x + 100, ay: start.y, shoot: false };
    inp[d] = true;
    for (let i = 0; i < 10; i++) { C.emit('input', inp); await wait(60); }
    const now = C.last('snap').players[0];
    moved = Math.hypot(now.x - start.x, now.y - start.y);
    if (moved > 25) break;
  }
  assert.ok(moved > 25, 'сервер применил ввод, герой сдвинулся на ' + Math.round(moved) + ' px');

  // выстрел приводит к появлению пуль
  C.emit('input', { ax: 9999, ay: 9999, shoot: true });
  const shot = await until(async () => {
    const s = C.last('snap');
    return s && s.players[0].am && s.bullets.length > 0 ? s : null;
  }, 6000);
  assert.ok(shot.bullets.length > 0, 'пули появились в снапшоте');
  C.close();
});

test('неверный код комнаты → понятная ошибка, без зависания', async () => {
  const D = await connect();
  D.emit('hello', { nick: 'Ошибочный', cls: 'student', location: 'mall', mode: 'coop', code: 'ZZZZ' });
  const err = await until(async () => D.last('errorMsg'));
  assert.ok(err.includes('ZZZZ'));
  D.close();
});
