'use strict';
// Тонкая обёртка над socket.io + helper для REST.
(function () {
  const Net = {
    socket: null,
    handlers: {},
    connected: false,

    init() {
      if (this.socket) return this.socket;
      this.socket = io({ transports: ['websocket', 'polling'] });
      this.socket.on('connect', () => { this.connected = true; this.fire('connect', {}); });
      this.socket.on('disconnect', () => { this.connected = false; this.fire('disconnect', {}); });
      ['joined', 'snap', 'stats', 'rooms', 'roomState', 'dead', 'errorMsg', 'started'].forEach((ev) => {
        this.socket.on(ev, (data) => this.fire(ev, data));
      });
      return this.socket;
    },

    on(ev, fn) {
      (this.handlers[ev] = this.handlers[ev] || []).push(fn);
      return this;
    },

    fire(ev, data) {
      (this.handlers[ev] || []).forEach((fn) => {
        try { fn(data); } catch (e) { console.error('[net] ' + ev, e); }
      });
    },

    emit(ev, data) {
      if (this.socket) this.socket.emit(ev, data);
    },

    async get(url) {
      const r = await fetch(url, { headers: { accept: 'application/json' } });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    },
  };

  window.Net = Net;
})();
