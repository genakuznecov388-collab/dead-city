'use strict';
// Отрисовка мира на Canvas 2D. Спрайты рисуются кодом — внешних картинок нет.
// Карты: map[] — коды препятствий, floor[] — типы пола, decor[] — украшения.
(function () {
  const ZCOLOR = {
    walker: ['#6b9e52', '#3f6130'],
    runner: ['#c9a54a', '#8a6f24'],
    spitter: ['#7fb7a1', '#3f6f5c'],
    tank: ['#8e6f4e', '#5b452c'],
    boss: ['#8d5578', '#4a2c40'],
  };

  // Коды препятствий (см. server/map.js)
  const O = { EMPTY: 0, WALL: 1, HOUSE: 2, PILLAR: 3, CAR: 4, BARREL: 5, CRATE: 6, MACHINE: 7, TREE: 8, FENCE: 9, TENT: 10, KIOSK: 11, SANDBAG: 12, BED: 13 };
  const F = { PLAIN: 0, ROAD_H: 1, ROAD_V: 2, ROAD_X: 3, SIDEWALK: 4, GRASS: 5, TILE: 6, CONCRETE: 7, SAND: 8, LINO: 9 };

  function hash(x, y) {
    let h = x * 374761393 + y * 668265263;
    h = (h ^ (h >> 13)) * 1274126177;
    return ((h ^ (h >> 16)) >>> 0) / 4294967296;
  }

  const DEFAULT_PALETTE = {
    f1: '#151a20', f2: '#181e25', road: '#22262b', roadEdge: '#2b3037', grass: '#1b2a1f',
    grass2: '#16211a', block: '#39332c', blockTop: '#4a4238', accent: '#6b9e52',
  };

  const Render = {
    cv: null, ctx: null, mini: null, mctx: null,
    map: null, floor: null, decor: [], tile: 48, cols: 0, rows: 0,
    palette: DEFAULT_PALETTE,
    particles: [], cam: { x: 0, y: 0 }, shake: 0, time: 0, w: 0, h: 0,

    init() {
      this.cv = document.getElementById('cv');
      this.ctx = this.cv.getContext('2d');
      this.mini = document.getElementById('mini');
      this.mctx = this.mini.getContext('2d');
      window.addEventListener('resize', () => this.resize());
      this.resize();
    },

    resize() {
      if (!this.cv) return;
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      this.cv.width = Math.floor(window.innerWidth * dpr);
      this.cv.height = Math.floor(window.innerHeight * dpr);
      this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      this.viewW = window.innerWidth;
      this.viewH = window.innerHeight;
    },

    setMap(data) {
      this.map = data.map;
      this.floor = data.floor;
      this.decor = data.decor || [];
      this.tile = data.tile;
      this.cols = data.cols;
      this.rows = data.rows;
      this.w = data.width;
      this.h = data.height;
      this.palette = data.palette || DEFAULT_PALETTE;
      this.cam.x = data.width / 2;
      this.cam.y = data.height / 2;
    },

    codeAt(cx, cy) {
      if (cx < 0 || cy < 0 || cx >= this.cols || cy >= this.rows) return O.WALL;
      return parseInt(this.map[cy][cx], 36) || 0;
    },
    floorAt(cx, cy) {
      if (cx < 0 || cy < 0 || cx >= this.cols || cy >= this.rows) return F.PLAIN;
      return parseInt(this.floor[cy][cx], 36) || 0;
    },
    isWall(cx, cy) { return this.codeAt(cx, cy) !== 0; },

    draw(world, dt) {
      if (!this.map) return;
      const ctx = this.ctx;
      const me = world.me;
      this.time += dt;
      const p = this.palette;

      let cx = me.x, cy = me.y;
      if (this.w < this.viewW) cx = this.w / 2; else cx = Math.max(this.viewW / 2, Math.min(this.w - this.viewW / 2, cx));
      if (this.h < this.viewH) cy = this.h / 2; else cy = Math.max(this.viewH / 2, Math.min(this.h - this.viewH / 2, cy));
      this.cam.x += (cx - this.cam.x) * Math.min(1, dt * 12);
      this.cam.y += (cy - this.cam.y) * Math.min(1, dt * 12);
      if (this.shake > 0) this.shake = Math.max(0, this.shake - dt * 40);

      const ox = -this.cam.x + this.viewW / 2 + (Math.random() - .5) * this.shake;
      const oy = -this.cam.y + this.viewH / 2 + (Math.random() - .5) * this.shake;

      ctx.fillStyle = '#06070a';
      ctx.fillRect(0, 0, this.viewW, this.viewH);

      const x0 = Math.max(0, Math.floor(-ox / this.tile)), x1 = Math.min(this.cols - 1, Math.floor((-ox + this.viewW) / this.tile));
      const y0 = Math.max(0, Math.floor(-oy / this.tile)), y1 = Math.min(this.rows - 1, Math.floor((-oy + this.viewH) / this.tile));

      this.drawFloors(ctx, ox, oy, x0, y0, x1, y1);
      this.drawDecor(ctx, ox, oy, x0, y0, x1, y1);
      this.drawObstacles(ctx, ox, oy, x0, y0, x1, y1);
      this.drawLoot(ctx, ox, oy, world.loot);
      this.drawTurrets(ctx, ox, oy, world.turrets);
      this.drawZombies(ctx, ox, oy, world, dt);
      this.drawPlayers(ctx, ox, oy, world);
      this.drawBullets(ctx, ox, oy, world.bullets);
      this.drawParticles(ctx, ox, oy, dt);
      this.drawDarkness(ctx, world);
      this.drawMini(world);
    },

    // --- полы ---------------------------------------------------------------
    drawFloors(ctx, ox, oy, x0, y0, x1, y1) {
      const t = this.tile, p = this.palette;
      for (let y = y0; y <= y1; y++) {
        for (let x = x0; x <= x1; x++) {
          const px = Math.floor(x * t + ox), py = Math.floor(y * t + oy);
          const kind = this.floorAt(x, y);
          const h = hash(x, y);
          switch (kind) {
            case F.ROAD_H:
            case F.ROAD_V:
            case F.ROAD_X: {
              ctx.fillStyle = p.road;
              ctx.fillRect(px, py, t, t);
              ctx.fillStyle = 'rgba(255,255,255,.05)';
              if (kind === F.ROAD_H) ctx.fillRect(px, py + t / 2 - 1.5, t, 3);
              else if (kind === F.ROAD_V) ctx.fillRect(px + t / 2 - 1.5, py, 3, t);
              if (h > 0.9) { ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.fillRect(px + 6, py + 8, 14, 5); }
              break;
            }
            case F.SIDEWALK: {
              ctx.fillStyle = p.roadEdge;
              ctx.fillRect(px, py, t, t);
              ctx.strokeStyle = 'rgba(0,0,0,.22)';
              ctx.lineWidth = 1;
              ctx.strokeRect(px + .5, py + .5, t - 1, t - 1);
              break;
            }
            case F.GRASS: {
              ctx.fillStyle = h > 0.5 ? p.grass : p.grass2;
              ctx.fillRect(px, py, t, t);
              if (h > 0.86) {
                ctx.fillStyle = 'rgba(120,180,90,.14)';
                ctx.fillRect(px + h * 30, py + (1 - h) * 34, 5, 3);
                ctx.fillRect(px + (1 - h) * 28, py + h * 26, 4, 3);
              }
              break;
            }
            case F.TILE: {
              ctx.fillStyle = (x + y) % 2 === 0 ? p.f1 : p.f2;
              ctx.fillRect(px, py, t, t);
              ctx.strokeStyle = 'rgba(255,255,255,.045)';
              ctx.lineWidth = 1;
              ctx.strokeRect(px + .5, py + .5, t / 2 - 1, t / 2 - 1);
              ctx.strokeRect(px + t / 2 + .5, py + t / 2 + .5, t / 2 - 1, t / 2 - 1);
              break;
            }
            case F.LINO: {
              ctx.fillStyle = (x + y) % 2 === 0 ? p.f1 : p.f2;
              ctx.fillRect(px, py, t, t);
              ctx.fillStyle = 'rgba(255,255,255,.03)';
              ctx.fillRect(px, py + t - 6, t, 3);
              break;
            }
            case F.SAND: {
              ctx.fillStyle = h > 0.5 ? p.f2 : p.f1;
              ctx.fillRect(px, py, t, t);
              ctx.fillStyle = 'rgba(255,235,180,.05)';
              for (let k = 0; k < 3; k++) {
                const hx = hash(x * 7 + k, y * 3 + k);
                ctx.fillRect(px + hx * t, py + h * t, 2, 2);
              }
              break;
            }
            case F.CONCRETE: {
              ctx.fillStyle = (x + y) % 2 === 0 ? p.f1 : p.f2;
              ctx.fillRect(px, py, t, t);
              ctx.strokeStyle = 'rgba(0,0,0,.22)';
              ctx.lineWidth = 1;
              if (x % 3 === 0) { ctx.beginPath(); ctx.moveTo(px + .5, py); ctx.lineTo(px + .5, py + t); ctx.stroke(); }
              if (y % 3 === 0) { ctx.beginPath(); ctx.moveTo(px, py + .5); ctx.lineTo(px + t, py + .5); ctx.stroke(); }
              if (h > 0.78) {
                ctx.strokeStyle = 'rgba(0,0,0,.32)';
                ctx.beginPath();
                ctx.moveTo(px + 6, py + 10);
                ctx.lineTo(px + 22, py + 20);
                ctx.lineTo(px + 16, py + 34);
                ctx.stroke();
              }
              if (h > 0.94) { ctx.fillStyle = 'rgba(255,255,255,.035)'; ctx.fillRect(px + 8, py + 8, 22, 18); }
              break;
            }
            default: {
              ctx.fillStyle = (x + y) % 2 === 0 ? p.f1 : p.f2;
              ctx.fillRect(px, py, t, t);
              if (h > 0.94) {
                ctx.fillStyle = 'rgba(142,38,38,.22)';
                ctx.beginPath(); ctx.arc(px + h * t, py + (1 - h) * t, 5 + h * 6, 0, Math.PI * 2); ctx.fill();
              }
            }
          }
        }
      }
    },

    // --- декор (плоский, под всеми) ----------------------------------------
    drawDecor(ctx, ox, oy, x0, y0, x1, y1) {
      const left = x0 * this.tile - 40, right = (x1 + 1) * this.tile + 40;
      const top = y0 * this.tile - 40, bottom = (y1 + 1) * this.tile + 40;
      for (const d of this.decor) {
        if (d.x < left || d.x > right || d.y < top || d.y > bottom) continue;
        const px = d.x + ox, py = d.y + oy, s = d.s || 1;
        switch (d.t) {
          case 'blood':
            ctx.fillStyle = 'rgba(120,20,20,.42)';
            ctx.beginPath(); ctx.ellipse(px, py, 12 * s, 8 * s, d.r, 0, Math.PI * 2); ctx.fill();
            ctx.beginPath(); ctx.ellipse(px + 10 * s, py + 5 * s, 4 * s, 3 * s, d.r, 0, Math.PI * 2); ctx.fill();
            break;
          case 'crack':
            ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.lineWidth = 1.5;
            ctx.beginPath(); ctx.moveTo(px - 12 * s, py); ctx.lineTo(px, py + 5 * s); ctx.lineTo(px + 13 * s, py - 7 * s); ctx.stroke();
            break;
          case 'puddle':
            ctx.fillStyle = 'rgba(70,110,140,.20)';
            ctx.beginPath(); ctx.ellipse(px, py, 16 * s, 10 * s, d.r, 0, Math.PI * 2); ctx.fill();
            break;
          case 'oil':
            ctx.fillStyle = 'rgba(15,15,18,.55)';
            ctx.beginPath(); ctx.ellipse(px, py, 15 * s, 11 * s, d.r, 0, Math.PI * 2); ctx.fill();
            break;
          case 'trash':
            ctx.fillStyle = 'rgba(190,190,180,.14)';
            ctx.fillRect(px - 6, py - 4, 9, 7); ctx.fillRect(px + 4, py + 2, 6, 5);
            break;
          case 'papers':
            ctx.fillStyle = 'rgba(225,225,215,.13)';
            ctx.fillRect(px - 7, py - 5, 12, 9); ctx.fillRect(px + 6, py + 4, 9, 7);
            break;
          case 'cone': {
            ctx.fillStyle = '#e07a2f';
            ctx.beginPath(); ctx.moveTo(px, py - 12); ctx.lineTo(px + 8, py + 8); ctx.lineTo(px - 8, py + 8); ctx.closePath(); ctx.fill();
            ctx.fillStyle = 'rgba(255,255,255,.6)'; ctx.fillRect(px - 5, py - 2, 10, 3);
            break;
          }
          case 'cart':
            ctx.strokeStyle = 'rgba(200,210,220,.35)'; ctx.lineWidth = 2;
            ctx.strokeRect(px - 10, py - 8, 20, 14);
            ctx.beginPath(); ctx.arc(px - 6, py + 8, 3, 0, Math.PI * 2); ctx.arc(px + 6, py + 8, 3, 0, Math.PI * 2); ctx.stroke();
            break;
          case 'sign':
            ctx.fillStyle = 'rgba(200,120,120,.4)';
            ctx.fillRect(px - 8, py - 6, 16, 12);
            break;
          case 'iv':
            ctx.strokeStyle = 'rgba(220,230,235,.5)'; ctx.lineWidth = 2;
            ctx.beginPath(); ctx.moveTo(px, py + 10); ctx.lineTo(px, py - 12); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(px - 6, py - 12); ctx.lineTo(px + 6, py - 12); ctx.stroke();
            break;
          case 'cable':
            ctx.strokeStyle = 'rgba(20,20,24,.7)'; ctx.lineWidth = 3;
            ctx.beginPath(); ctx.moveTo(px - 18, py); ctx.bezierCurveTo(px - 6, py + 12, px + 6, py - 12, px + 18, py); ctx.stroke();
            break;
          case 'sparks':
            ctx.fillStyle = 'rgba(255,180,90,.35)';
            ctx.beginPath(); ctx.arc(px, py, 3 * s, 0, Math.PI * 2); ctx.fill();
            break;
          case 'tracks':
            ctx.fillStyle = 'rgba(0,0,0,.28)';
            ctx.fillRect(px - 14, py - 3, 28, 5); ctx.fillRect(px - 14, py + 7, 28, 5);
            break;
          case 'sand':
            ctx.fillStyle = 'rgba(190,170,110,.12)';
            ctx.beginPath(); ctx.ellipse(px, py, 18 * s, 11 * s, d.r, 0, Math.PI * 2); ctx.fill();
            break;
          case 'bush':
            ctx.fillStyle = 'rgba(60,110,60,.5)';
            ctx.beginPath(); ctx.arc(px, py, 10 * s, 0, Math.PI * 2); ctx.fill();
            break;
          case 'tree':
            ctx.fillStyle = 'rgba(0,0,0,.35)';
            ctx.beginPath(); ctx.ellipse(px + 6, py + 10, 16, 7, 0, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = '#2f4a2c';
            ctx.beginPath(); ctx.arc(px, py, 18 * s, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = '#3d6136';
            ctx.beginPath(); ctx.arc(px - 5, py - 5, 12 * s, 0, Math.PI * 2); ctx.fill();
            break;
          default:
            break;
        }
      }
    },

    // --- препятствия --------------------------------------------------------
    drawObstacles(ctx, ox, oy, x0, y0, x1, y1) {
      const t = this.tile, p = this.palette;
      for (let y = y0 - 1; y <= y1 + 1; y++) {
        for (let x = x0 - 1; x <= x1 + 1; x++) {
          const code = this.codeAt(x, y);
          if (code === O.EMPTY) continue;
          const px = x * t + ox, py = y * t + oy;
          const h = hash(x, y);
          switch (code) {
            case O.WALL: {
              ctx.fillStyle = '#0d1116';
              ctx.fillRect(px, py, t, t);
              ctx.fillStyle = p.block;
              ctx.fillRect(px + 1, py + 1, t - 3, t - 3);
              ctx.fillStyle = p.blockTop;
              ctx.fillRect(px + 1, py + 1, t - 3, 4);
              break;
            }
            case O.HOUSE: {
              const above = this.codeAt(x, y - 1) === O.HOUSE;
              ctx.fillStyle = '#0e1216';
              ctx.fillRect(px, py, t, t);
              ctx.fillStyle = p.block;
              ctx.fillRect(px + 1, py + 1, t - 2, t - 2);
              if (!above) {
                ctx.fillStyle = '#4a4238';
                ctx.fillRect(px + 1, py + 1, t - 2, 12);
                ctx.fillStyle = 'rgba(0,0,0,.35)';
                ctx.fillRect(px + 1, py + 13, t - 2, 2);
              }
              if (h > 0.72) {
                ctx.fillStyle = 'rgba(255,214,140,.16)';
                ctx.fillRect(px + 10, py + 20, 10, 12);
              }
              break;
            }
            case O.PILLAR: {
              ctx.fillStyle = 'rgba(0,0,0,.45)';
              ctx.beginPath(); ctx.ellipse(px + t / 2 + 4, py + t / 2 + 6, 17, 10, 0, 0, Math.PI * 2); ctx.fill();
              ctx.fillStyle = p.blockTop;
              ctx.beginPath(); ctx.arc(px + t / 2, py + t / 2, 17, 0, Math.PI * 2); ctx.fill();
              ctx.fillStyle = p.block;
              ctx.beginPath(); ctx.arc(px + t / 2 - 2, py + t / 2 - 2, 12, 0, Math.PI * 2); ctx.fill();
              break;
            }
            case O.CAR: {
              ctx.save();
              ctx.translate(px + t / 2, py + t / 2);
              ctx.rotate(h > 0.5 ? 0 : Math.PI / 2);
              ctx.fillStyle = 'rgba(0,0,0,.4)';
              ctx.fillRect(-20, -11, 42, 26);
              ctx.fillStyle = h > 0.7 ? '#4a5560' : h > 0.4 ? '#5c4a3a' : '#3f4a52';
              ctx.fillRect(-21, -12, 42, 24);
              ctx.fillStyle = '#2a3138';
              ctx.fillRect(-6, -10, 16, 20);
              ctx.fillStyle = 'rgba(150,190,210,.25)';
              ctx.fillRect(9, -8, 8, 16);
              ctx.restore();
              break;
            }
            case O.BARREL: {
              ctx.fillStyle = 'rgba(0,0,0,.4)';
              ctx.beginPath(); ctx.ellipse(px + t / 2 + 3, py + t / 2 + 5, 12, 8, 0, 0, Math.PI * 2); ctx.fill();
              ctx.fillStyle = h > 0.66 ? '#7a3a2a' : h > 0.33 ? '#3f4a3a' : '#4a4a52';
              ctx.beginPath(); ctx.arc(px + t / 2, py + t / 2, 12, 0, Math.PI * 2); ctx.fill();
              ctx.strokeStyle = 'rgba(255,255,255,.16)'; ctx.lineWidth = 2;
              ctx.beginPath(); ctx.arc(px + t / 2, py + t / 2, 7, 0, Math.PI * 2); ctx.stroke();
              break;
            }
            case O.CRATE: {
              ctx.fillStyle = 'rgba(0,0,0,.4)';
              ctx.fillRect(px + 6, py + 8, 36, 34);
              ctx.fillStyle = '#6b5334';
              ctx.fillRect(px + 5, py + 6, 36, 34);
              ctx.strokeStyle = 'rgba(0,0,0,.3)'; ctx.lineWidth = 2;
              ctx.strokeRect(px + 5, py + 6, 36, 34);
              ctx.beginPath(); ctx.moveTo(px + 5, py + 6); ctx.lineTo(px + 41, py + 40);
              ctx.moveTo(px + 41, py + 6); ctx.lineTo(px + 5, py + 40); ctx.stroke();
              break;
            }
            case O.MACHINE: {
              ctx.fillStyle = 'rgba(0,0,0,.4)';
              ctx.fillRect(px + 3, py + 6, 44, 40);
              ctx.fillStyle = '#3b3b42';
              ctx.fillRect(px + 2, py + 4, 44, 40);
              ctx.fillStyle = '#2a2a30';
              ctx.fillRect(px + 6, py + 8, 36, 12);
              ctx.fillStyle = 'rgba(230,180,60,.55)';
              for (let k = 0; k < 4; k++) ctx.fillRect(px + 8 + k * 9, py + 26, 6, 12);
              break;
            }
            case O.TREE: {
              ctx.fillStyle = 'rgba(0,0,0,.4)';
              ctx.beginPath(); ctx.ellipse(px + t / 2 + 5, py + t / 2 + 8, 16, 9, 0, 0, Math.PI * 2); ctx.fill();
              ctx.fillStyle = '#2c4529';
              ctx.beginPath(); ctx.arc(px + t / 2, py + t / 2, 19, 0, Math.PI * 2); ctx.fill();
              ctx.fillStyle = '#3b5c34';
              ctx.beginPath(); ctx.arc(px + t / 2 - 6, py + t / 2 - 6, 12, 0, Math.PI * 2); ctx.fill();
              break;
            }
            case O.FENCE: {
              ctx.strokeStyle = '#5a5346'; ctx.lineWidth = 3;
              ctx.beginPath();
              ctx.moveTo(px + 6, py + t / 2); ctx.lineTo(px + t - 6, py + t / 2);
              ctx.stroke();
              ctx.lineWidth = 4;
              ctx.beginPath();
              ctx.moveTo(px + 10, py + 12); ctx.lineTo(px + 10, py + t - 10);
              ctx.moveTo(px + t - 10, py + 12); ctx.lineTo(px + t - 10, py + t - 10);
              ctx.stroke();
              break;
            }
            case O.TENT: {
              ctx.fillStyle = 'rgba(0,0,0,.35)';
              ctx.fillRect(px + 4, py + 8, 42, 38);
              ctx.fillStyle = '#4c5330';
              ctx.fillRect(px + 2, py + 6, 44, 38);
              ctx.fillStyle = '#3b4226';
              ctx.beginPath(); ctx.moveTo(px + 2, py + 6); ctx.lineTo(px + 24, py + 2); ctx.lineTo(px + 46, py + 6); ctx.closePath(); ctx.fill();
              ctx.fillStyle = 'rgba(0,0,0,.35)';
              ctx.fillRect(px + 26, py + 12, 8, 32);
              break;
            }
            case O.KIOSK: {
              ctx.fillStyle = '#2b3340';
              ctx.fillRect(px + 1, py + 4, t - 2, t - 4);
              ctx.fillStyle = p.accent;
              ctx.globalAlpha = .35; ctx.fillRect(px + 4, py + 8, t - 8, t - 16); ctx.globalAlpha = 1;
              ctx.fillStyle = '#1b2027';
              ctx.fillRect(px + 1, py + t - 12, t - 2, 12);
              break;
            }
            case O.SANDBAG: {
              const up = this.codeAt(x, y - 1) === O.SANDBAG;
              ctx.fillStyle = 'rgba(0,0,0,.35)';
              ctx.fillRect(px + 2, py + 10, t - 4, t - 14);
              ctx.fillStyle = '#6a6244';
              ctx.fillRect(px + 2, py + 8, t - 4, t - 14);
              if (!up) {
                ctx.fillStyle = '#7d7450';
                ctx.beginPath(); ctx.arc(px + 14, py + 16, 10, 0, Math.PI * 2); ctx.arc(px + 32, py + 18, 10, 0, Math.PI * 2); ctx.fill();
              }
              ctx.strokeStyle = 'rgba(0,0,0,.25)';
              ctx.beginPath(); ctx.moveTo(px + 2, py + t - 6); ctx.lineTo(px + t - 2, py + t - 6); ctx.stroke();
              break;
            }
            case O.BED: {
              ctx.fillStyle = 'rgba(0,0,0,.35)';
              ctx.fillRect(px + 4, py + 8, 40, 32);
              ctx.fillStyle = '#c9d3d6';
              ctx.fillRect(px + 3, py + 6, 40, 32);
              ctx.fillStyle = '#8fa9ad';
              ctx.fillRect(px + 3, py + 6, 40, 10);
              ctx.strokeStyle = 'rgba(0,0,0,.3)'; ctx.lineWidth = 1.5;
              ctx.strokeRect(px + 3, py + 6, 40, 32);
              break;
            }
            default: {
              ctx.fillStyle = p.block;
              ctx.fillRect(px, py, t, t);
            }
          }
        }
      }
    },

    drawLoot(ctx, ox, oy, loot) {
      const ICON = { medkit: '+', ammo: 'A', weapon: 'W', fuel: 'F' };
      for (const l of loot) {
        const bob = Math.sin(this.time * 3 + l.x * 0.02) * 3;
        const px = l.x + ox, py = l.y + oy + bob;
        const col = { medkit: '#ff6b6b', ammo: '#ffd479', weapon: '#8fd6ff', fuel: '#ff9a3c' }[l.t] || '#fff';
        ctx.save();
        ctx.shadowColor = col; ctx.shadowBlur = 14;
        ctx.fillStyle = 'rgba(10,12,16,.9)';
        ctx.beginPath(); ctx.arc(px, py, 12, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = col; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(px, py, 12, 0, Math.PI * 2); ctx.stroke();
        ctx.fillStyle = col; ctx.font = 'bold 13px Segoe UI, sans-serif';
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(ICON[l.t] || '?', px, py + 1);
        ctx.restore();
      }
    },

    drawTurrets(ctx, ox, oy, turrets) {
      for (const t of turrets) {
        ctx.save();
        ctx.translate(t.x + ox, t.y + oy);
        ctx.fillStyle = 'rgba(0,0,0,.4)';
        ctx.beginPath(); ctx.ellipse(4, 8, 14, 7, 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#2b3a4a';
        ctx.beginPath(); ctx.arc(0, 0, 13, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#6fa8dc'; ctx.lineWidth = 2; ctx.stroke();
        ctx.fillStyle = '#8fd6ff';
        ctx.fillRect(0, -3, 18, 6);
        ctx.restore();
      }
    },

    drawZombies(ctx, ox, oy, world, dt) {
      for (const z of world.zombies) {
        const px = z.x + ox, py = z.y + oy;
        if (px < -90 || py < -90 || px > this.viewW + 90 || py > this.viewH + 90) continue;
        const col = ZCOLOR[z.t] || ZCOLOR.walker;
        const r = z.r;
        ctx.fillStyle = 'rgba(0,0,0,.35)';
        ctx.beginPath(); ctx.ellipse(px, py + r * 0.75, r * 0.9, r * 0.42, 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = col[1];
        ctx.beginPath(); ctx.arc(px, py, r, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = col[0];
        ctx.beginPath(); ctx.arc(px, py - 2, r * 0.78, 0, Math.PI * 2); ctx.fill();
        const ang = z.ang || 0;
        ctx.strokeStyle = col[0];
        ctx.lineWidth = Math.max(3, r * 0.28);
        ctx.beginPath();
        ctx.moveTo(px + Math.cos(ang + 0.5) * r * 0.4, py + Math.sin(ang + 0.5) * r * 0.4);
        ctx.lineTo(px + Math.cos(ang + 0.35) * r * 1.5, py + Math.sin(ang + 0.35) * r * 1.5);
        ctx.moveTo(px + Math.cos(ang - 0.5) * r * 0.4, py + Math.sin(ang - 0.5) * r * 0.4);
        ctx.lineTo(px + Math.cos(ang - 0.35) * r * 1.5, py + Math.sin(ang - 0.35) * r * 1.5);
        ctx.stroke();
        ctx.fillStyle = z.burn ? '#ffb347' : '#ffe9a8';
        ctx.beginPath();
        ctx.arc(px + Math.cos(ang - 0.28) * r * 0.42, py + Math.sin(ang - 0.28) * r * 0.42, 2.3, 0, Math.PI * 2);
        ctx.arc(px + Math.cos(ang + 0.28) * r * 0.42, py + Math.sin(ang + 0.28) * r * 0.42, 2.3, 0, Math.PI * 2);
        ctx.fill();
        if (z.burn) {
          ctx.globalAlpha = 0.5 + Math.sin(this.time * 18) * 0.2;
          ctx.fillStyle = '#ff7a2f';
          ctx.beginPath(); ctx.arc(px, py - r * 0.6, r * 0.7, 0, Math.PI * 2); ctx.fill();
          ctx.globalAlpha = 1;
        }
        if (z.stun) {
          ctx.strokeStyle = 'rgba(255,255,255,.7)'; ctx.lineWidth = 1.5;
          ctx.beginPath(); ctx.arc(px, py, r + 5, 0, Math.PI * 2); ctx.stroke();
        }
        if (z.m > 100 || z.h < z.m) {
          const bw = Math.max(26, r * 2.2);
          ctx.fillStyle = 'rgba(0,0,0,.65)';
          ctx.fillRect(px - bw / 2, py - r - 11, bw, 5);
          ctx.fillStyle = z.boss ? '#c86bff' : '#d94f4f';
          ctx.fillRect(px - bw / 2, py - r - 11, bw * Math.max(0, z.h / z.m), 5);
        }
      }
    },

    drawPlayers(ctx, ox, oy, world) {
      for (const p of world.players) {
        const px = p.x + ox, py = p.y + oy;
        const r = 14;
        ctx.fillStyle = 'rgba(0,0,0,.4)';
        ctx.beginPath(); ctx.ellipse(px, py + 11, 13, 6, 0, 0, Math.PI * 2); ctx.fill();

        if (p.downed) {
          ctx.save(); ctx.translate(px, py); ctx.rotate(Math.PI / 2);
          ctx.fillStyle = '#5b6b7a';
          ctx.beginPath(); ctx.arc(0, 0, r * 0.9, 0, Math.PI * 2); ctx.fill();
          ctx.restore();
          ctx.fillStyle = '#ffd479'; ctx.font = 'bold 12px Segoe UI'; ctx.textAlign = 'center';
          ctx.fillText('ПОДНИМИ (E)', px, py - 24);
          ctx.fillStyle = 'rgba(0,0,0,.7)'; ctx.fillRect(px - 22, py + 16, 44, 5);
          ctx.fillStyle = '#ffd479'; ctx.fillRect(px - 22, py + 16, 44 * (1 - p.downTimer / 25), 5);
          continue;
        }
        if (p.dead) continue;

        const cls = p.color || '#8ab4f8';
        if (p.dashing) { // след рывка
          ctx.globalAlpha = 0.35;
          ctx.fillStyle = cls;
          for (let k = 1; k <= 3; k++) {
            ctx.beginPath();
            ctx.arc(px - Math.cos(p.ang) * 16 * k, py - Math.sin(p.ang) * 16 * k, r * (0.8 - k * 0.18), 0, Math.PI * 2);
            ctx.fill();
          }
          ctx.globalAlpha = 1;
        }
        const walk = Math.sin(this.time * 12 + (p.moving ? 1 : 0)) * (p.moving ? 4 : 0);
        ctx.strokeStyle = '#1a1f26'; ctx.lineWidth = 4; ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(px - 5, py + 4); ctx.lineTo(px - 5 + walk, py + 13);
        ctx.moveTo(px + 5, py + 4); ctx.lineTo(px + 5 - walk, py + 13);
        ctx.stroke();
        ctx.fillStyle = cls;
        ctx.beginPath(); ctx.arc(px, py - 1, r * 0.86, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = 'rgba(0,0,0,.5)'; ctx.lineWidth = 2; ctx.stroke();
        ctx.fillStyle = '#e8d3b0';
        ctx.beginPath(); ctx.arc(px, py - 3, r * 0.42, 0, Math.PI * 2); ctx.fill();
        const ang = p.ang || 0;
        ctx.strokeStyle = '#20262e'; ctx.lineWidth = 6;
        ctx.beginPath();
        ctx.moveTo(px + Math.cos(ang) * 6, py + Math.sin(ang) * 6);
        ctx.lineTo(px + Math.cos(ang) * 24, py + Math.sin(ang) * 24);
        ctx.stroke();
        if (p.shotT > 0) {
          ctx.fillStyle = 'rgba(255,220,140,' + Math.min(1, p.shotT * 8) + ')';
          ctx.beginPath();
          ctx.arc(px + Math.cos(ang) * 27, py + Math.sin(ang) * 27, 6, 0, Math.PI * 2);
          ctx.fill();
        }
        if (p.prot) {
          ctx.strokeStyle = 'rgba(140,220,255,.8)'; ctx.lineWidth = 2;
          ctx.beginPath(); ctx.arc(px, py, r + 6, 0, Math.PI * 2); ctx.stroke();
        }
        if (p.immune) {
          ctx.strokeStyle = 'rgba(126,214,165,.9)'; ctx.lineWidth = 3;
          ctx.beginPath(); ctx.arc(px, py, r + 9, 0, Math.PI * 2); ctx.stroke();
        }
        ctx.font = 'bold 12px Segoe UI, sans-serif'; ctx.textAlign = 'center';
        ctx.fillStyle = p.me ? '#ffd479' : 'rgba(230,240,250,.85)';
        ctx.fillText(p.nick + (p.me ? ' (ты)' : ''), px, py - r - 14);
        ctx.fillStyle = 'rgba(0,0,0,.65)'; ctx.fillRect(px - 18, py - r - 10, 36, 4);
        ctx.fillStyle = p.hp / p.maxHp > 0.35 ? '#7bd88f' : '#d94f4f';
        ctx.fillRect(px - 18, py - r - 10, 36 * Math.max(0, p.hp / p.maxHp), 4);
      }
    },

    drawBullets(ctx, ox, oy, bullets) {
      for (const b of bullets) {
        const px = b.x + ox, py = b.y + oy;
        if (px < -30 || py < -30 || px > this.viewW + 30 || py > this.viewH + 30) continue;
        ctx.save();
        ctx.shadowColor = b.c; ctx.shadowBlur = 10;
        ctx.fillStyle = b.c;
        if (b.fx) {
          ctx.globalAlpha = 0.5;
          ctx.beginPath(); ctx.arc(px, py, b.r, 0, Math.PI * 2); ctx.fill();
        } else {
          ctx.beginPath(); ctx.arc(px, py, b.r, 0, Math.PI * 2); ctx.fill();
          ctx.globalAlpha = 0.35;
          ctx.beginPath();
          ctx.arc(px - b.vx * 0.012, py - b.vy * 0.012, b.r * 0.8, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
      }
    },

    spawnBlood(x, y, n, color) {
      for (let i = 0; i < n; i++) {
        const a = Math.random() * Math.PI * 2, s = 40 + Math.random() * 160;
        this.particles.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: 0.4 + Math.random() * 0.4, max: 0.8, r: 2 + Math.random() * 2.5, c: color || '#8e2626' });
      }
      if (this.particles.length > 500) this.particles.splice(0, this.particles.length - 500);
    },

    drawParticles(ctx, ox, oy, dt) {
      for (let i = this.particles.length - 1; i >= 0; i--) {
        const p = this.particles[i];
        p.life -= dt;
        if (p.life <= 0) { this.particles.splice(i, 1); continue; }
        p.x += p.vx * dt; p.y += p.vy * dt;
        p.vx *= 0.93; p.vy *= 0.93;
        ctx.globalAlpha = Math.max(0, p.life / p.max);
        ctx.fillStyle = p.c;
        ctx.beginPath(); ctx.arc(p.x + ox, p.y + oy, p.r, 0, Math.PI * 2); ctx.fill();
      }
      ctx.globalAlpha = 1;
    },

    drawDarkness(ctx, world) {
      const me = world.me;
      const px = me.x + (-this.cam.x + this.viewW / 2), py = me.y + (-this.cam.y + this.viewH / 2);
      const dark = world.darkness || 0.2;
      const grad = ctx.createRadialGradient(px, py, 90, px, py, Math.max(this.viewW, this.viewH) * 0.62);
      grad.addColorStop(0, 'rgba(0,0,0,0)');
      grad.addColorStop(0.55, 'rgba(0,0,0,' + (dark * 0.5).toFixed(3) + ')');
      grad.addColorStop(1, 'rgba(0,0,0,' + Math.min(0.92, 0.35 + dark).toFixed(3) + ')');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, this.viewW, this.viewH);

      if (world.me.inf >= 60) {
        ctx.fillStyle = 'rgba(90,170,60,' + ((world.me.inf - 60) / 100 * 0.28).toFixed(3) + ')';
        ctx.fillRect(0, 0, this.viewW, this.viewH);
      }
      if (world.me.hp / world.me.maxHp < 0.3) {
        const g2 = ctx.createRadialGradient(this.viewW / 2, this.viewH / 2, Math.min(this.viewW, this.viewH) * 0.25, this.viewW / 2, this.viewH / 2, Math.max(this.viewW, this.viewH) * 0.6);
        g2.addColorStop(0, 'rgba(140,0,0,0)');
        g2.addColorStop(1, 'rgba(150,0,0,.42)');
        ctx.fillStyle = g2; ctx.fillRect(0, 0, this.viewW, this.viewH);
      }
    },

    drawMini(world) {
      const c = this.mctx, w = this.mini.width, h = this.mini.height;
      c.clearRect(0, 0, w, h);
      c.fillStyle = 'rgba(8,10,14,.8)';
      c.fillRect(0, 0, w, h);
      const sx = w / this.w, sy = h / this.h;
      c.fillStyle = 'rgba(120,135,155,.35)';
      for (let y = 0; y < this.rows; y += 2) {
        for (let x = 0; x < this.cols; x += 2) {
          if (this.isWall(x, y)) c.fillRect(x * this.tile * sx, y * this.tile * sy, this.tile * sx * 2, this.tile * sy * 2);
        }
      }
      c.fillStyle = '#d94f4f';
      for (const z of world.zombies) c.fillRect(z.x * sx - 1, z.y * sy - 1, 2.4, 2.4);
      for (const p of world.players) {
        c.fillStyle = p.me ? '#ffd479' : '#7bd88f';
        c.beginPath(); c.arc(p.x * sx, p.y * sy, p.me ? 3.4 : 2.6, 0, Math.PI * 2); c.fill();
      }
      c.strokeStyle = 'rgba(255,255,255,.25)'; c.lineWidth = 1;
      c.strokeRect(0.5, 0.5, w - 1, h - 1);
    },
  };

  window.Render = Render;
})();
