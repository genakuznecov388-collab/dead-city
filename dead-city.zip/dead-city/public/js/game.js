'use strict';
// Клиент: экраны, ввод, сеть, интерполяция и HUD.
(function () {
  const $ = (id) => document.getElementById(id);
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

  const S = {
    content: null,
    nick: localStorage.getItem('dc_nick') || '',
    cls: localStorage.getItem('dc_cls') || 'soldier',
    loc: localStorage.getItem('dc_loc') || 'suburb',
    mode: 'solo',
    youId: null,
    room: null,        // данные joined
    snaps: [],         // буфер снапшотов
    me: { x: 0, y: 0 },
    keys: {},
    mouse: { x: 0, y: 0 },
    dead: false,
    lastSend: 0,
    lastShotAt: 0,
    perkOpen: false,
    lastSnap: null,
    prevSnap: null,
    started: false,
    online: 0,
    toastTimer: null,
    invPrev: 0,
  };

  // ---------- экраны и мелочи ----------
  function show(id) {
    document.querySelectorAll('.screen').forEach((s) => s.classList.remove('active'));
    $('screen-' + id).classList.add('active');
  }

  function toast(msg) {
    let t = document.querySelector('.toast');
    if (!t) { t = document.createElement('div'); t.className = 'toast'; document.body.appendChild(t); }
    t.textContent = msg;
    clearTimeout(S.toastTimer);
    S.toastTimer = setTimeout(() => t.remove(), 3200);
  }

  function setNums(payload) {
    $('online-count').textContent = payload.online ?? 0;
    $('online-ingame').textContent = payload.inGame ?? 0;
    $('online-rooms').textContent = payload.rooms ?? 0;
    $('online-runs').textContent = payload.runs ?? 0;
    const go = $('game-online'); if (go) go.textContent = payload.online ?? 0;
  }

  // ---------- загрузка ----------
  async function boot() {
    Net.init();
    Render.init();
    bindUi();
    bindKeys();

    const tips = [
      'Совет: стрельба создаёт шум — толпа идёт на звук.',
      'Совет: в кооперативе павшего поднимают клавишей E.',
      'Совет: каждую пятую волну приходит босс.',
    ];
    $('splash-tip').innerHTML = '<b>' + tips[0] + '</b>';
    const started = performance.now();
    const MIN_SPLASH = 5200; // надписи должны успеть прочитаться

    let bar = 0;
    let tipIdx = 0;
    const barTimer = setInterval(() => {
      const t = (performance.now() - started) / MIN_SPLASH;
      bar = Math.min(94, t * 94 + Math.random() * 3);
      $('splash-bar').style.width = bar.toFixed(1) + '%';
    }, 130);
    const tipTimer = setInterval(() => {
      if (S.content) tipIdx = (tipIdx + 1) % S.content.tips.length;
      else tipIdx = (tipIdx + 1) % tips.length;
      const text = S.content ? S.content.tips[tipIdx] : tips[tipIdx % tips.length];
      $('splash-tip').innerHTML = '<b>' + (S.content ? 'Совет: ' : '') + escapeHtml(text) + '</b>';
    }, 1650);

    try {
      S.content = await Net.get('/api/content');
      $('splash-status').textContent = 'Готово. Игру создал Airon.';
    } catch (e) {
      $('splash-status').textContent = 'Нет связи с сервером — проверь, запущен ли сервер игры.';
    }

    const left = MIN_SPLASH - (performance.now() - started);
    if (left > 0) await new Promise((r) => setTimeout(r, left));
    clearInterval(barTimer); clearInterval(tipTimer);
    $('splash-bar').style.width = '100%';
    await new Promise((r) => setTimeout(r, 700));

    buildLoadout();
    refreshBoard();
    show('menu');
    if (S.params.has('demo')) autoDemo();
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  // ---------- привязка UI ----------
  function bindUi() {
    $('nick').value = S.nick;
    $('nick').addEventListener('input', () => { S.nick = $('nick').value.trim().slice(0, 16); localStorage.setItem('dc_nick', S.nick); });

    $('btn-solo').onclick = () => openLoadout('solo');
    $('btn-coop').onclick = () => openLoadout('coop');
    $('btn-join').onclick = () => {
      const code = ($('join-code').value || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 4);
      if (code.length < 4) return toast('Код комнаты — 4 символа');
      openLoadout('coop', code);
    };
    $('btn-board').onclick = () => { refreshBoard(); show('board'); };
    $('btn-board-back').onclick = () => show('menu');
    $('btn-board2').onclick = () => { refreshBoard(); show('board'); };
    $('btn-donate').onclick = () => openShop();
    $('btn-shop-back').onclick = () => show('menu');
    $('btn-pay-cancel').onclick = () => { $('pay-overlay').classList.add('hidden'); S.pendingBuy = null; };
    $('btn-paid').onclick = () => submitOrder();
    $('btn-copy-card').onclick = () => {
      const num = ($('pay-cardnum').textContent || '').replace(/\s/g, '');
      navigator.clipboard?.writeText(num).then(() => toast('Номер карты скопирован'), () => toast(num));
    };
    $('btn-help').onclick = () => showHelp();
    $('btn-help-close').onclick = () => { $('help-overlay').classList.add('hidden'); };
    $('btn-back').onclick = () => show('menu');
    $('btn-go').onclick = () => startRun();
    $('btn-leave-lobby').onclick = () => { Net.emit('leave'); S.room = null; show('menu'); };
    $('btn-copy').onclick = () => {
      const url = location.origin + '/?room=' + (S.room ? S.room.code : '');
      navigator.clipboard?.writeText(url).then(() => toast('Ссылка скопирована: ' + url), () => toast(url));
    };
    $('btn-start').onclick = () => Net.emit('start');
    $('btn-resume').onclick = () => { $('pause-overlay').classList.add('hidden'); S.paused = false; };
    $('btn-menu3').onclick = () => { $('pause-overlay').classList.add('hidden'); Net.emit('leave'); S.paused = false; show('menu'); };
    $('btn-menu2').onclick = () => { S.dead = false; Net.emit('leave'); show('menu'); };
    $('btn-again').onclick = () => { $('dead-overlay').classList.add('hidden'); S.dead = false; Net.emit('leave'); startRun(); };

    const params = new URLSearchParams(location.search);
    S.params = params;
    const room = params.get('room');
    if (room) $('join-code').value = room.toUpperCase().slice(0, 4);
  }

  // Быстрый вход по ссылке: /?demo=1&nick=Имя&cls=soldier&loc=mall&mode=coop&room=ABCD
  function autoDemo() {
    const p = S.params;
    S.nick = p.get('nick') || localStorage.getItem('dc_nick') || 'Гость';
    $('nick').value = S.nick;
    if (p.get('cls') && S.content.classes[p.get('cls')]) S.cls = p.get('cls');
    if (p.get('loc') && S.content.locations[p.get('loc')]) S.loc = p.get('loc');
    S.mode = p.get('mode') === 'coop' ? 'coop' : 'solo';
    S.pendingCode = (p.get('room') || '').toUpperCase().slice(0, 4) || null;
    syncLoadout();
    startRun();
  }

  function showHelp() {
    const tips = (S.content && S.content.tips) || [];
    $('help-tips').innerHTML =
      '<p><b>WASD / стрелки</b> — движение, <b>мышь</b> — прицел, <b>ЛКМ</b> — огонь (можно удерживать), ' +
      '<b>Пробел</b> — классовая способность, <b>E</b> (удерживать) — поднять товарища, ' +
      '<b>1–4</b> — сменить оружие, <b>Esc</b> — пауза.</p>' +
      '<p style="margin-top:10px">Убийства дают опыт и очки. Уровень — выбор из трёх перков. Оружие, патроны ' +
      'и аптечки выпадают из зомби и лежат на карте. Смерть — окончательная: результат уходит в таблицу лидеров.</p>' +
      '<p style="margin-top:10px"><b>Советы:</b></p><ul style="padding-left:20px">' +
      tips.map((t) => '<li style="margin:4px 0">' + escapeHtml(t) + '</li>').join('') + '</ul>';
    $('help-overlay').classList.remove('hidden');
  }

  function openLoadout(mode, code) {
    if (!S.nick) return toast('Сначала введи ник');
    localStorage.setItem('dc_nick', S.nick);
    S.mode = mode;
    S.pendingCode = code || null;
    $('loadout-mode').textContent = (mode === 'solo' ? 'Одиночный рейд' : 'Кооператив' + (code ? ' · комната ' + code : '')) + ' · игрок: ' + S.nick;
    syncLoadout();
    show('loadout');
  }

  function buildLoadout() {
    if (!S.content) return;
    const cc = $('class-cards');
    cc.innerHTML = '';
    Object.values(S.content.classes).forEach((c) => {
      const el = document.createElement('div');
      el.className = 'pick';
      el.dataset.id = c.id;
      el.innerHTML =
        '<div class="name"><span class="circle" style="background:' + c.color + '">' + escapeHtml(c.icon) + '</span>' + escapeHtml(c.name) + '</div>' +
        '<div class="desc">' + escapeHtml(c.desc) + '</div>' +
        '<div class="nums">' +
        '<span class="chip">❤ ' + c.hp + '</span>' +
        '<span class="chip">⚡ ' + c.speed + '</span>' +
        '<span class="chip">💥 ×' + c.dmg.toFixed(2) + '</span>' +
        '<span class="chip">🎯 ' + escapeHtml((S.content.weapons[c.weapon] || {}).name || '') + '</span>' +
        '</div>' +
        '<div class="ability">● ' + escapeHtml(c.ability.name) + ' — ' + escapeHtml(c.ability.desc) + ' (КД ' + c.ability.cd + 'с)</div>';
      el.onclick = () => { S.cls = c.id; localStorage.setItem('dc_cls', c.id); syncLoadout(); };
      cc.appendChild(el);
    });

    const lc = $('loc-cards');
    lc.innerHTML = '';
    Object.values(S.content.locations).forEach((l) => {
      const el = document.createElement('div');
      el.className = 'pick';
      el.dataset.id = l.id;
      el.innerHTML =
        '<div class="name">' + escapeHtml(l.name) + '</div>' +
        '<div class="nums"><span class="diff">' + '★'.repeat(l.diff) + '☆'.repeat(5 - l.diff) + '</span>' +
        '<span class="chip">очки ×' + l.mul.toFixed(1) + '</span></div>' +
        '<div class="desc">' + escapeHtml(l.desc) + '</div>';
      el.onclick = () => { S.loc = l.id; localStorage.setItem('dc_loc', l.id); syncLoadout(); };
      lc.appendChild(el);
    });
  }

  function syncLoadout() {
    document.querySelectorAll('#class-cards .pick').forEach((el) => el.classList.toggle('sel', el.dataset.id === S.cls));
    document.querySelectorAll('#loc-cards .pick').forEach((el) => el.classList.toggle('sel', el.dataset.id === S.loc));
    const c = S.content && S.content.classes[S.cls];
    const l = S.content && S.content.locations[S.loc];
    if (c && l) $('loadout-summary').textContent = c.name + ' · ' + l.name + ' · сложность ' + l.diff + '/5 · очки ×' + l.mul.toFixed(1);
  }

  // ---------- сеть ----------
  function bindNet() {
    Net.on('stats', setNums);

    Net.on('rooms', (list) => {
      const box = $('rooms-list');
      if (!list || !list.length) { box.innerHTML = '<div class="dim">Пока никто не играет — создай первую комнату.</div>'; return; }
      box.innerHTML = '';
      list.forEach((r) => {
        const row = document.createElement('div');
        row.className = 'prow';
        const locName = (S.content && S.content.locations[r.location] && S.content.locations[r.location].name) || r.location;
        row.innerHTML = '<span class="circle" style="background:#d94f4f">' + r.players + '</span>' +
          '<b>' + escapeHtml(locName) + '</b>' +
          '<span class="dim">волна ' + r.wave + ' · ' + r.players + '/' + r.max + '</span>' +
          '<span class="host">' + escapeHtml(r.code) + '</span>';
        row.style.cursor = 'pointer';
        row.onclick = () => { $('join-code').value = r.code; openLoadout('coop', r.code); };
        box.appendChild(row);
      });
    });

    Net.on('joined', (data) => {
      S.room = data;
      S.youId = data.youId;
      S.snaps = [];
      S.dead = false;
      S.paused = false;
      S.perkOpen = false;
      S.started = data.mode === 'solo';
      const locDef = (S.content && S.content.locations[data.location]) || null;
      Render.setMap(Object.assign({}, data, { palette: locDef ? locDef.palette : null }));
      if (data.mode === 'coop' && !S.started) {
        $('lobby-code').textContent = data.code;
        $('screen-lobby').classList.add('active');
        document.querySelectorAll('.screen').forEach((s) => { if (s.id !== 'screen-lobby') s.classList.remove('active'); });
      } else {
        enterGame();
      }
    });

    Net.on('started', () => { enterGame(true); });

    Net.on('roomState', (st) => {
      if (!st) return;
      const box = $('lobby-players');
      box.innerHTML = '';
      st.players.forEach((p) => {
        const row = document.createElement('div');
        row.className = 'prow';
        const c = S.content && S.content.classes[p.cls];
        row.innerHTML = '<span class="circle" style="background:' + ((c && c.color) || '#888') + '">' + escapeHtml((c && c.icon) || '?') + '</span>' +
          '<b>' + escapeHtml(p.nick) + '</b><span class="dim">' + escapeHtml((c && c.name) || p.cls) + '</span>' +
          (p.host ? '<span class="host">хозяин комнаты</span>' : '');
        box.appendChild(row);
      });
      $('lobby-wait').textContent = st.players.length < 2
        ? 'Ждём игроков — можно начать и одному, но вдвоём веселее.'
        : 'Игроков: ' + st.players.length + '. Как только все готовы — хозяин жмёт «Начать рейд».';
      $('btn-start').disabled = st.players.length ? (st.players[0].id !== S.youId) : true;
    });

    Net.on('snap', (snap) => {
      if (!S.room) return;
      S.prevSnap = S.lastSnap;
      S.lastSnap = snap;
      const recv = performance.now();
      S.snaps.push({ t: recv, data: snap });
      if (S.snaps.length > 12) S.snaps.shift();
      const mine = snap.players.find((p) => p.i === S.youId);
      if (mine) {
        if (!S.started && snap.phase !== 'lobby') S.started = true;
        updateHud(snap, mine);
        if (mine.dead === 1 && !S.dead) onDeathLocal(snap, mine);
      }
    });

    Net.on('dead', (d) => {
      S.dead = true;
      $('dead-score').textContent = d.score;
      $('dead-kills').textContent = d.kills;
      $('dead-wave').textContent = d.wave;
      $('dead-rank').textContent = '#' + d.rank;
      const titles = ['Ты мёртв', 'Тебя сожрали', 'Конец рейда', 'Зомби победили'];
      $('dead-title').textContent = titles[Math.floor(Math.random() * titles.length)];
      $('dead-sub').textContent = d.inTop
        ? 'Результат в таблице лидеров — место #' + d.rank + '.'
        : 'Результат сохранён, но в топ-50 пока не попал (место #' + d.rank + ').';
      $('dead-overlay').classList.remove('hidden');
      refreshBoard();
    });

    Net.on('errorMsg', (m) => toast(m));
    Net.on('connect', () => toast('Связь с сервером установлена'));
    Net.on('disconnect', () => toast('Связь с сервером потеряна — переподключение…'));
  }

  function enterGame(started) {
    document.querySelectorAll('.screen').forEach((s) => s.classList.remove('active'));
    $('screen-game').classList.add('active');
    $('dead-overlay').classList.add('hidden');
    $('perk-overlay').classList.add('hidden');
    $('pause-overlay').classList.add('hidden');
    S.started = true;
    Render.resize();
    $('txt-room').textContent = (S.room.mode === 'coop' ? 'Комната ' + S.room.code : 'Одиночный рейд') + ' · ' + S.room.locationName;
    if (!S.loopStarted) { S.loopStarted = true; requestAnimationFrame(loop); }
  }

  // ---------- ввод ----------
  function bindKeys() {
    window.addEventListener('keydown', (e) => {
      const k = e.key.toLowerCase();
      S.keys[k] = true;
      if ([' ', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright'].includes(k)) e.preventDefault();
      if (k === 'escape' && S.room && S.started && !S.dead) {
        S.paused = !S.paused;
        $('pause-overlay').classList.toggle('hidden', !S.paused);
      }
      if (!S.room || S.dead) return;
      if (k === ' ') Net.emit('ability');
      if (['1', '2', '3', '4'].includes(k)) Net.emit('swap', Number(k) - 1);
    });
    window.addEventListener('keyup', (e) => { S.keys[e.key.toLowerCase()] = false; });
    window.addEventListener('blur', () => { S.keys = {}; });
    const cv = $('cv');
    cv.addEventListener('mousemove', (e) => { S.mouse.x = e.clientX; S.mouse.y = e.clientY; });
    cv.addEventListener('mousedown', (e) => { if (e.button === 0) S.mouseDown = true; });
    window.addEventListener('mouseup', (e) => { if (e.button === 0) S.mouseDown = false; });
    cv.addEventListener('contextmenu', (e) => e.preventDefault());
  }

  function sendInput() {
    if (!S.room) return;
    const now = performance.now();
    if (now - S.lastSend < 40) return;
    S.lastSend = now;
    const k = S.keys;
    const aim = screenToWorld(S.mouse.x, S.mouse.y);
    Net.emit('input', {
      up: !!(k['w'] || k['ц'] || k['arrowup']),
      down: !!(k['s'] || k['ы'] || k['arrowdown']),
      left: !!(k['a'] || k['ф'] || k['arrowleft']),
      right: !!(k['d'] || k['в'] || k['arrowright']),
      ax: aim.x, ay: aim.y,
      shoot: !!S.mouseDown && !S.paused && !S.dead,
      revive: !!(k['e'] || k['у']),
    });
  }

  function screenToWorld(sx, sy) {
    return { x: sx - window.innerWidth / 2 + Render.cam.x, y: sy - window.innerHeight / 2 + Render.cam.y };
  }

  // локальная коллизия (та же логика, что на сервере) — для предсказания
  function wallAt(x, y) {
    const cx = Math.floor(x / Render.tile), cy = Math.floor(y / Render.tile);
    return Render.isWall(cx, cy);
  }
  function freeCircle(x, y, r) {
    for (const dx of [-r, 0, r]) for (const dy of [-r, 0, r]) {
      if (wallAt(x + dx, y + dy)) return false;
    }
    return true;
  }

  // ---------- игровой цикл ----------
  let lastFrame = performance.now();
  function loop(now) {
    const dt = Math.min(0.05, (now - lastFrame) / 1000);
    lastFrame = now;
    try {
      if (S.room && S.started) {
        sendInput();
        if (!S.dead) predictMe(dt);
        const world = buildWorld(dt);
        Render.draw(world, dt);
        checkPerk();
      }
    } catch (e) {
      console.error('[loop]', e);
    }
    requestAnimationFrame(loop);
  }

  // предсказание движения своего героя
  function predictMe(dt) {
    const mine = S.lastSnap && S.lastSnap.players.find((p) => p.i === S.youId);
    if (!mine || mine.dead || mine.d === 1) { S.pred = null; return; }
    // во время рывка героем управляет сервер — не мешаем
    if (mine.dsh === 1) { S.pred = { x: mine.x, y: mine.y }; S.moving = true; return; }
    const c = S.content && S.content.classes[mine.cls];
    if (!c) return;
    if (!S.pred || isFinite(S.pred.x) === false) S.pred = { x: mine.x, y: mine.y };
    // коррекция к серверу
    const err = Math.hypot(S.pred.x - mine.x, S.pred.y - mine.y);
    if (err > 160) { S.pred.x = mine.x; S.pred.y = mine.y; }
    else { S.pred.x += (mine.x - S.pred.x) * Math.min(1, dt * 6); S.pred.y += (mine.y - S.pred.y) * Math.min(1, dt * 6); }

    const k = S.keys;
    let dx = (k['d'] || k['в'] || k['arrowright'] ? 1 : 0) - (k['a'] || k['ф'] || k['arrowleft'] ? 1 : 0);
    let dy = (k['s'] || k['ы'] || k['arrowdown'] ? 1 : 0) - (k['w'] || k['ц'] || k['arrowup'] ? 1 : 0);
    if (dx || dy) {
      const len = Math.hypot(dx, dy); dx /= len; dy /= len;
      let speed = c.speed;
      if (mine.pr && mine.pr.includes('speed')) speed *= 1.10;
      if (mine.abo > 0 && c.ability.id === 'adrenaline') speed *= 1.6;
      const step = speed * dt;
      if (freeCircle(S.pred.x + dx * step, S.pred.y, 14)) S.pred.x += dx * step;
      if (freeCircle(S.pred.x, S.pred.y + dy * step, 14)) S.pred.y += dy * step;
      S.pred.x = clamp(S.pred.x, 14, Render.w - 14);
      S.pred.y = clamp(S.pred.y, 14, Render.h - 14);
      S.moving = true;
    } else S.moving = false;
  }

  function lerp(a, b, t) { return a + (b - a) * t; }

  function buildWorld(dt) {
    const snaps = S.snaps;
    const cur = snaps[snaps.length - 1].data;
    const prev = snaps.length > 1 ? snaps[snaps.length - 2].data : cur;
    const dtSnap = snaps.length > 1 ? Math.max(16, snaps[snaps.length - 1].t - snaps[snaps.length - 2].t) : 50;
    const since = performance.now() - snaps[snaps.length - 1].t;
    const alpha = clamp(since / dtSnap, 0, 1.5);

    const byId = (arr) => { const m = {}; for (const e of arr) m[e.i] = e; return m; };
    const prevP = byId(prev.players), curP = byId(cur.players);
    const prevZ = byId(prev.zombies), curZ = byId(cur.zombies);

    const players = cur.players.map((p) => {
      const q = prevP[p.i] || p;
      const isMe = p.i === S.youId;
      let x = lerp(q.x, p.x, alpha), y = lerp(q.y, p.y, alpha);
      if (isMe && S.pred && !p.dead) { x = S.pred.x; y = S.pred.y; }
      // вспышка выстрела: сброс локального таймера при изменении оружия/выстрела
      return {
        id: p.i, x, y, ang: lerp(q.a, p.a, alpha), nick: p.nick, cls: p.cls,
        hp: p.hp, maxHp: p.mh, downed: p.d === 1, dead: p.dead === 1, me: isMe,
        color: ((S.content && S.content.classes[p.cls]) || {}).color, prot: p.prot === 1,
        moving: isMe ? !!S.moving : Math.abs(p.x - q.x) + Math.abs(p.y - q.y) > 1,
        shotT: isMe && S.mouseDown && !S.dead ? 1 : 0,
        dashing: p.dsh === 1, immune: p.imm === 1,
        downTimer: p.rv || 0,
      };
    });

    S.zAngles = S.zAngles || {};
    const me0 = players.find((p) => p.me) || { x: 0, y: 0 };
    const zombies = cur.zombies.map((z) => {
      const q = prevZ[z.i] || z;
      const x = lerp(q.x, z.x, alpha), y = lerp(q.y, z.y, alpha);
      const dx = z.x - q.x, dy = z.y - q.y;
      let ang = S.zAngles[z.i];
      if (dx * dx + dy * dy > 1) { ang = Math.atan2(dy, dx); S.zAngles[z.i] = ang; }
      if (ang === undefined) ang = Math.atan2(me0.y - y, me0.x - x);
      return { id: z.i, x, y, ang, t: z.t, r: z.r, hp: z.h, m: z.m, burn: z.b === 1, stun: z.s === 1, boss: z.t === 'boss' };
    });

    const bullets = cur.bullets.map((b) => ({
      x: b.x + b.vx * (alpha * dtSnap / 1000), y: b.y + b.vy * (alpha * dtSnap / 1000),
      vx: b.vx, vy: b.vy, r: b.r, c: b.c, fx: b.vx === 0 && b.vy === 0,
    }));

    // кровь при уроне зомби
    if (S.prevZombieHp) {
      for (const z of zombies) {
        const old = S.prevZombieHp[z.id];
        if (old !== undefined && z.hp < old) Render.spawnBlood(z.x, z.y, 3);
      }
    }
    S.prevZombieHp = {}; for (const z of zombies) S.prevZombieHp[z.id] = z.hp;

    const meP = players.find((p) => p.me) || { x: 0, y: 0, hp: 1, maxHp: 1, inf: 0 };
    const mine = cur.players.find((p) => p.i === S.youId) || {};
    const roomLoc = (S.room && S.room.location) || 'suburb';
    const locDef = (S.content && S.content.locations[roomLoc]) || null;

    return {
      players, zombies, bullets,
      loot: cur.loot, turrets: cur.turrets,
      me: { x: meP.x, y: meP.y, hp: mine.hp || 0, maxHp: mine.mh || 1, inf: mine.inf || 0 },
      darkness: locDef ? locDef.dark : 0.2,
    };
  }

  // ---------- HUD ----------
  function updateHud(snap, mine) {
    const hpPct = Math.max(0, mine.hp / mine.mh) * 100;
    $('bar-hp').style.width = hpPct + '%';
    $('txt-hp').textContent = mine.hp + ' / ' + mine.mh;
    $('bar-inf').style.width = Math.round(mine.inf) + '%';
    $('txt-inf').textContent = 'Заражение ' + Math.round(mine.inf) + '%' + (mine.inf >= 100 ? ' (критично!)' : '');
    $('bar-xp').style.width = Math.min(100, (mine.xp / mine.xn) * 100) + '%';
    $('txt-lvl').textContent = 'Уровень ' + mine.lv + ' · перков: ' + (mine.pr ? mine.pr.length : 0) +
      (mine.pm ? ' · донат-перков: ' + mine.pm : '');

    $('txt-wave').textContent = snap.phase === 'lobby' ? 'Ожидание' : 'Волна ' + snap.wave;
    $('txt-left').textContent = 'Зомби: ' + snap.left;
    $('txt-phase').textContent = snap.phase === 'break' ? 'Следующая волна через ' + Math.ceil(snap.nextIn) + ' с'
      : snap.phase === 'lobby' ? 'Хозяин комнаты ещё не начал рейд' : '';

    $('txt-score').textContent = mine.sc;
    $('txt-kills').textContent = mine.k;
    const w = (S.content && S.content.weapons[mine.w]) || { name: mine.w, ammo: 'inf' };
    $('txt-weapon').textContent = w.name || mine.w;
    $('txt-ammo').textContent = w.ammo === 'inf' ? '∞' : (mine.am[w.ammo] || 0);
    const c = (S.content && S.content.classes[mine.cls]) || { ability: { name: '—' } };
    $('txt-ability').textContent = c.ability.name;
    $('txt-ability-cd').textContent = mine.ab > 0 ? mine.ab.toFixed(1) + ' с' : 'готово';
    $('txt-ability-cd').className = 'cd' + (mine.ab > 0 ? '' : ' ability-ready');
    $('txt-weapons').textContent = (mine.wl || []).map((k, i) => (i + 1) + ':' + (((S.content || {}).weapons && S.content.weapons[k] || {}).name || k)).join('   ');

    const box = $('hud-players');
    box.innerHTML = '';
    snap.players.forEach((p) => {
      const row = document.createElement('div');
      const col = ((S.content && S.content.classes[p.cls]) || {}).color || '#888';
      row.innerHTML = '<span style="color:' + col + '">●</span> ' + escapeHtml(p.nick) +
        ' <span class="dim">' + p.sc + '</span>' + (p.dead ? ' <span style="color:#d94f4f">†</span>' : '');
      box.appendChild(row);
    });
  }

  function onDeathLocal(snap, mine) {
    S.dead = true;
    $('dead-score').textContent = mine.sc;
    $('dead-kills').textContent = mine.k;
    $('dead-wave').textContent = snap.wave;
    if ($('dead-overlay').classList.contains('hidden')) {
      $('dead-title').textContent = 'Ты мёртв';
      $('dead-sub').textContent = 'Результат отправлен в таблицу лидеров.';
      $('dead-overlay').classList.remove('hidden');
    }
  }

  // ---------- перки ----------
  function checkPerk() {
    const mine = S.lastSnap && S.lastSnap.players.find((p) => p.i === S.youId);
    if (!mine) return;
    if (mine.of && mine.of.length && !S.perkOpen) {
      S.perkOpen = true;
      const box = $('perk-cards');
      box.innerHTML = '';
      mine.of.forEach((o) => {
        const el = document.createElement('div');
        el.className = 'perk';
        el.innerHTML = '<div class="pn">' + escapeHtml(o.name) + '</div><div class="pd">' + escapeHtml(o.desc) + '</div>';
        el.onclick = () => { Net.emit('perk', o.id); S.perkOpen = false; $('perk-overlay').classList.add('hidden'); };
        box.appendChild(el);
      });
      $('perk-overlay').classList.remove('hidden');
    }
    if (!mine.of && S.perkOpen) { S.perkOpen = false; $('perk-overlay').classList.add('hidden'); }
  }

  // ---------- рейд ----------
  function startRun() {
    if (!S.nick) return toast('Сначала введи ник');
    S.dead = false;
    S.paused = false;
    S.pred = null;
    S.snaps = [];
    S.lastSnap = null;
    S.prevZombieHp = null;
    $('dead-overlay').classList.add('hidden');
    Net.emit('hello', {
      nick: S.nick, cls: S.cls, location: S.loc, mode: S.mode, code: S.pendingCode || null,
    });
  }

  // ---------- донат-магазин ----------
  let shopData = null;
  let myShopState = null;

  const el = (tag, cls, html) => {
    const d = document.createElement(tag);
    if (cls) d.className = cls;
    if (html != null) d.innerHTML = html;
    return d;
  };
  const statusRu = (s) => ({ pending: 'ждёт подтверждения', paid: 'оплачено ✓', rejected: 'отклонено' }[s] || s);

  async function openShop() {
    $('shop-nick').textContent = S.nick || 'не указан';
    show('shop');
    $('shop-cards').innerHTML = '<div class="dim" style="padding:20px">Загрузка…</div>';
    try {
      if (!shopData) shopData = await Net.get('/api/shop');
      myShopState = S.nick ? await Net.get('/api/shop/my?nick=' + encodeURIComponent(S.nick)) : null;
      renderShop();
    } catch (e) {
      $('shop-cards').innerHTML = '<div class="dim" style="padding:20px">Не удалось загрузить магазин — проверь связь с сервером.</div>';
    }
  }

  function ownedLevel(perkId) {
    return (myShopState && myShopState.perks && Number(myShopState.perks[perkId])) || 0;
  }

  function renderShop() {
    if (!shopData) return;
    // что уже куплено + заявки
    const own = $('shop-owned');
    const badges = [];
    if (myShopState && myShopState.xp2) badges.push('<span class="owned">×2 опыт — навсегда</span>');
    for (const p of shopData.perks) {
      const lv = ownedLevel(p.id);
      if (lv) badges.push('<span class="owned">' + escapeHtml(p.name) + ' — ур. ' + lv + '</span>');
    }
    own.innerHTML = '<b>Твои покупки:</b> ' +
      (badges.length ? '<div class="owned-line">' + badges.join('') + '</div>' : '<span class="dim"> пока пусто</span>') +
      (myShopState && myShopState.orders && myShopState.orders.length
        ? '<div style="margin-top:12px"><b>Заявки:</b>' + myShopState.orders.slice(0, 6).map((o) =>
            '<div class="order-row"><span>' + (o.kind === 'xpx2' ? 'Двойной опыт' : escapeHtml(o.perkId) + ' · уровень ' + o.level) +
            '</span><span>' + o.amount + ' ₽</span><span class="st ' + o.status + '">' + statusRu(o.status) + '</span></div>').join('') + '</div>'
        : '');

    const box = $('shop-cards');
    box.innerHTML = '';

    // двойной опыт
    const dx = shopData.doubleXp;
    const c0 = el('div', 'pick');
    c0.appendChild(el('div', 'name', '⭐ ' + escapeHtml(dx.name)));
    c0.appendChild(el('div', 'desc', escapeHtml(dx.desc)));
    const lv0 = el('div', 'levels');
    if (myShopState && myShopState.xp2) {
      lv0.appendChild(el('button', 'lvbtn owned', 'Уже куплено ✓'));
    } else {
      const b = el('button', 'lvbtn', 'Купить за <b>' + dx.price + ' ₽</b>');
      b.onclick = () => askBuy('xpx2', null, 0, dx.name, dx.price);
      lv0.appendChild(b);
    }
    c0.appendChild(lv0);
    box.appendChild(c0);

    // перки
    for (const p of shopData.perks) {
      const card = el('div', 'pick');
      card.appendChild(el('div', 'name', escapeHtml(p.name)));
      card.appendChild(el('div', 'desc', escapeHtml(p.desc)));
      const row = el('div', 'levels');
      const owned = ownedLevel(p.id);
      for (const L of p.levels) {
        if (L.level <= owned) {
          row.appendChild(el('button', 'lvbtn owned', 'ур. ' + L.level + ' ✓'));
        } else {
          const b = el('button', 'lvbtn', 'ур. ' + L.level + ' — <b>' + L.price + ' ₽</b>');
          b.onclick = () => askBuy('perk', p.id, L.level, p.name + ' — уровень ' + L.level, L.price);
          row.appendChild(b);
        }
      }
      card.appendChild(row);
      box.appendChild(card);
    }
  }

  function askBuy(kind, perkId, level, title, amount) {
    if (!S.nick) return toast('Сначала введи ник в главном меню — покупка привязывается к нику');
    S.pendingBuy = { kind, perkId, level, title, amount };
    $('pay-title').textContent = title;
    $('pay-sub').textContent = 'Перевод на карту, затем нажми «Я оплатил(а)»';
    $('pay-amount').textContent = amount + ' ₽';
    $('pay-nick').textContent = S.nick;
    $('pay-overlay').classList.remove('hidden');
  }

  async function submitOrder() {
    if (!S.pendingBuy) return;
    const btn = $('btn-paid');
    btn.disabled = true;
    try {
      const r = await fetch('/api/shop/order', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ nick: S.nick, kind: S.pendingBuy.kind, perkId: S.pendingBuy.perkId, level: S.pendingBuy.level }),
      });
      const d = await r.json();
      if (!r.ok || d.error) { toast(d.error || 'Не получилось отправить заявку'); return; }
      $('pay-overlay').classList.add('hidden');
      toast('Заявка отправлена! Перк включится после подтверждения оплаты.');
      S.pendingBuy = null;
      myShopState = await Net.get('/api/shop/my?nick=' + encodeURIComponent(S.nick));
      renderShop();
    } catch (e) {
      toast('Ошибка отправки заявки — проверь связь');
    } finally {
      btn.disabled = false;
    }
  }

  // ---------- таблица лидеров ----------
  async function refreshBoard() {
    try {
      const data = await Net.get('/api/leaderboard');
      $('board-total').textContent = data.total;
      const body = $('board-body');
      if (!data.top.length) { body.innerHTML = '<tr><td colspan="8" class="empty">Пока никто не выжил. Стань первым.</td></tr>'; return; }
      const medals = ['🥇', '🥈', '🥉'];
      body.innerHTML = data.top.map((r, i) => {
        const cls = (S.content && S.content.classes[r.cls] && S.content.classes[r.cls].name) || r.cls;
        const loc = (S.content && S.content.locations[r.location] && S.content.locations[r.location].name) || r.location;
        const mine = r.nick === S.nick;
        return '<tr' + (mine ? ' class="me"' : '') + '><td class="rank">' + (medals[i] || (i + 1)) + '</td>' +
          '<td>' + escapeHtml(r.nick) + '</td><td>' + escapeHtml(cls) + '</td><td>' + escapeHtml(loc) + '</td>' +
          '<td>' + (r.mode === 'coop' ? 'кооп' : 'одиночный') + '</td>' +
          '<td class="num">' + r.wave + '</td><td class="num">' + r.kills + '</td><td class="num"><b>' + r.score + '</b></td></tr>';
      }).join('');
    } catch (e) {
      $('board-body').innerHTML = '<tr><td colspan="8" class="empty">Не удалось загрузить таблицу.</td></tr>';
    }
  }

  document.addEventListener('DOMContentLoaded', () => { bindNet(); boot(); });
})();
