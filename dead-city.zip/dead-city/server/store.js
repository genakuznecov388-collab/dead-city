'use strict';
const fs = require('fs');
const path = require('path');

const FILE = process.env.SCORES_FILE || path.join(__dirname, '..', 'data', 'scores.json');
const MAX_KEEP = 400; // храним запас, отдаём топ-50

function ensureDir() {
  const dir = path.dirname(FILE);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

function sanitizeNick(nick) {
  return String(nick || '')
    .replace(/[<>&"'`\\\/]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 16) || 'Безымянный';
}

function load() {
  try {
    ensureDir();
    if (!fs.existsSync(FILE)) return [];
    const raw = fs.readFileSync(FILE, 'utf8');
    const data = JSON.parse(raw);
    return Array.isArray(data.scores) ? data.scores : [];
  } catch (e) {
    console.error('[store] не смог прочитать scores.json:', e.message);
    return [];
  }
}

function save(list) {
  ensureDir();
  const tmp = FILE + '.tmp';
  const payload = JSON.stringify({ updated: new Date().toISOString(), scores: list }, null, 0);
  fs.writeFileSync(tmp, payload, 'utf8');
  fs.renameSync(tmp, FILE);
}

function rankOf(list, score) {
  let rank = 1;
  for (const s of list) if (s.score > score) rank++;
  return rank;
}

// Возвращает {rank, inTop} — место в общем зачёте.
function addScore(entry) {
  const list = load();
  const clean = {
    nick: sanitizeNick(entry.nick),
    score: Math.max(0, Math.floor(entry.score || 0)),
    kills: Math.max(0, Math.floor(entry.kills || 0)),
    wave: Math.max(1, Math.floor(entry.wave || 1)),
    level: Math.max(1, Math.floor(entry.level || 1)),
    cls: String(entry.cls || 'soldier').slice(0, 20),
    location: String(entry.location || 'suburb').slice(0, 24),
    mode: entry.mode === 'coop' ? 'coop' : 'solo',
    date: new Date().toISOString(),
  };
  const rank = rankOf(list, clean.score);
  list.push(clean);
  list.sort((a, b) => b.score - a.score || a.kills - b.kills);
  save(list.slice(0, MAX_KEEP));
  return { rank, inTop: rank <= 50 };
}

function top(n = 50) {
  const list = load();
  list.sort((a, b) => b.score - a.score);
  return list.slice(0, Math.max(1, Math.min(50, n)));
}

function totalRuns() {
  return load().length;
}

module.exports = { addScore, top, totalRuns, load, sanitizeNick, FILE };
