'use strict';
// Контент игры: классы, локации, оружие, зомби, перки, советы.
// Здесь только данные — вся логика в game.js.

const TIPS = [
  'Игру создал Airon — он же и виноват в том, что зомби уже стучат в дверь.',
  'Стрельба создаёт шум: чем чаще жмёшь гашетку, тем больше ходоков идёт на звук.',
  'Заражение от укуса не проходит само. Аптечка снижает его, пока ты жив.',
  'Строитель ставит турель — она стреляет сама, но живёт недолго. Береги её.',
  'Патроны конечны у всех, кроме пистолета. Меняй оружие клавишами 1–4.',
  'Толстяка не убить в лоб с пистолета — обходи и бей в спину или бери дробовик.',
  'Уровень даёт выбор из трёх перков. Комбинируй: урон + скорострельность работает лучше всего.',
  'В кооперативе павшего можно поднять: подойди и удерживай E, пока не встанет.',
  'Босс приходит каждую пятую волну. Перед ним лучше найти аптечку.',
  'Студент получает больше опыта — качайся быстро, но держись подальше от толпы.',
  'Пожарник почти не боится огня, но зомби горят и поджигают своих.',
  'Военная база даёт больше очков, но зомби там злее. Не лезь туда новичком.',
];

const WEAPONS = {
  pistol: { name: 'Пистолет ПМ', dmg: 13, rate: 0.30, speed: 900, spread: 0.03, pellets: 1, auto: false, ammo: 'inf', pierce: 0, sound: 1.0, color: '#ffd479', bulletR: 3, shots: 1 },
  smg: { name: 'ПП «Вихрь»', dmg: 9, rate: 0.085, speed: 950, spread: 0.09, pellets: 1, auto: true, ammo: 'light', sound: 1.2, color: '#ffe9a8', bulletR: 3, shots: 1 },
  rifle: { name: 'Автомат АК', dmg: 18, rate: 0.14, speed: 1150, spread: 0.055, pellets: 1, auto: true, ammo: 'heavy', sound: 1.5, color: '#ffcf5c', bulletR: 3.5, shots: 1 },
  shotgun: { name: 'Дробовик', dmg: 10, rate: 0.85, speed: 820, spread: 0.30, pellets: 8, auto: false, ammo: 'heavy', sound: 2.0, color: '#ffb347', bulletR: 3, shots: 1, knock: 1 },
  flamer: { name: 'Огнемёт', dmg: 5, rate: 0.05, speed: 440, spread: 0.30, pellets: 1, auto: true, ammo: 'fuel', sound: 0.4, color: '#ff7a2f', bulletR: 6, life: 0.34, fire: true },
  axe: { name: 'Пожарный топор', dmg: 34, rate: 0.62, speed: 0, spread: 0, pellets: 0, auto: false, ammo: 'inf', sound: 0.2, color: '#d9d9d9', melee: 62, knock: 1 },
};

const CLASSES = {
  soldier: {
    id: 'soldier', name: 'Солдат', icon: 'S', color: '#6fa8dc',
    desc: 'Автомат, повышенный урон. Владеет очередью: 6 секунд шквального огня.',
    hp: 130, speed: 168, dmg: 1.15, rate: 1.05, xp: 1.0, hurt: 1.0,
    weapon: 'rifle', ammo: { heavy: 60, light: 0, fuel: 0 },
    ability: { id: 'burst', name: 'Очередь', cd: 24, dur: 6, desc: 'Урон +50%, патроны не тратятся.' },
  },
  fireman: {
    id: 'fireman', name: 'Пожарник', icon: 'F', color: '#e06666',
    desc: 'Топор и защита от огня. Поджигает всё вокруг себя.',
    hp: 155, speed: 156, dmg: 1.0, rate: 1.0, xp: 1.0, hurt: 0.88,
    weapon: 'axe', ammo: { heavy: 24, light: 0, fuel: 40 },
    ability: { id: 'flame', name: 'Огненный шлейф', cd: 18, dur: 4, desc: 'Волна огня вокруг: жжёт зомби 4 секунды.' },
  },
  police: {
    id: 'police', name: 'Полиция', icon: 'P', color: '#7ba7e0',
    desc: 'Быстрый и точный. Вспышка оглушает зомби рядом.',
    hp: 115, speed: 186, dmg: 1.2, rate: 1.1, xp: 1.0, hurt: 1.0,
    weapon: 'pistol', ammo: { heavy: 18, light: 40, fuel: 0 },
    ability: { id: 'flash', name: 'Слепящая вспышка', cd: 16, dur: 3, desc: 'Зомби в радиусе 260 оглушены 3 секунды.' },
  },
  student: {
    id: 'student', name: 'Студент', icon: 'У', color: '#93c47d',
    desc: 'Слабый, но учится втрое быстрее: свой опыт +50%.',
    hp: 92, speed: 176, dmg: 0.95, rate: 1.25, xp: 1.5, hurt: 1.05,
    weapon: 'pistol', ammo: { heavy: 0, light: 60, fuel: 0 },
    ability: { id: 'adrenaline', name: 'Адреналин', cd: 20, dur: 7, desc: 'Скорость +60%, урон +20%.' },
  },
  builder: {
    id: 'builder', name: 'Строитель', icon: 'B', color: '#e6b26b',
    desc: 'Дробовик и турель. Ставит автоматическую пушку на 22 секунды.',
    hp: 165, speed: 148, dmg: 1.05, rate: 1.0, xp: 1.0, hurt: 0.95,
    weapon: 'shotgun', ammo: { heavy: 40, light: 0, fuel: 0 },
    ability: { id: 'turret', name: 'Турель', cd: 30, dur: 22, desc: 'Автоматическая пушка стреляет сама.' },
  },
  athlete: {
    id: 'athlete', name: 'Спортсмен', icon: 'А', color: '#7ed6a5',
    desc: 'Самый быстрый: разрывает кольцо зомби рывком и уходит живым.',
    hp: 120, speed: 206, dmg: 1.05, rate: 1.05, xp: 1.1, hurt: 1.0,
    weapon: 'pistol', ammo: { heavy: 0, light: 45, fuel: 0 },
    ability: { id: 'dash', name: 'Рывок', cd: 11, dur: 0.30, desc: 'Рывок вперёд, 1 секунда неуязвимости.' },
  },
};

const LOCATIONS = {
  suburb: {
    id: 'suburb', name: 'Тихий район', diff: 1, mul: 1.0, dark: 0.10,
    desc: 'Асфальт, частные дома и пустые дворы. Лучшее место, чтобы освоиться.',
    zombies: ['walker', 'walker', 'runner'], density: 0.14,
    layout: 'blocks', maxObstacle: 6,
    palette: { f1: '#17211a', f2: '#1a241c', road: '#22262b', roadEdge: '#2b3037', grass: '#1b2a1f', grass2: '#16211a', block: '#39332c', blockTop: '#4a4238', accent: '#6b9e52' },
  },
  mall: {
    id: 'mall', name: 'ТЦ «Гранд Плаза»', diff: 2, mul: 1.3, dark: 0.16,
    desc: 'Где всё и началось. Плитка, колонны, витрины и много лута.',
    zombies: ['walker', 'runner', 'spitter'], density: 0.22,
    layout: 'hall', maxObstacle: 5,
    palette: { f1: '#1e2229', f2: '#232830', road: '#2a2f38', roadEdge: '#333a45', grass: '#20242c', grass2: '#1b1f26', block: '#2c3340', blockTop: '#3b4454', accent: '#8b7bd8' },
  },
  hospital: {
    id: 'hospital', name: 'Городская больница', diff: 3, mul: 1.7, dark: 0.22,
    desc: 'Коридоры, палаты и очень злые пациенты. Больше аптечек.',
    zombies: ['runner', 'walker', 'spitter', 'tank'], density: 0.26,
    layout: 'wards', maxObstacle: 5,
    palette: { f1: '#1c2426', f2: '#202a2c', road: '#26302f', roadEdge: '#2e3a38', grass: '#1b2523', grass2: '#172020', block: '#2b3a38', blockTop: '#3a4d4a', accent: '#7fb7a1' },
  },
  factory: {
    id: 'factory', name: 'Завод «Красный Октябрь»', diff: 4, mul: 2.2, dark: 0.26,
    desc: 'Цеха, станки и орды. Ошибок здесь не прощают.',
    zombies: ['runner', 'tank', 'spitter', 'walker'], density: 0.30,
    layout: 'machines', maxObstacle: 5,
    palette: { f1: '#231f18', f2: '#272319', road: '#2d281c', roadEdge: '#372f21', grass: '#231f18', grass2: '#1e1b15', block: '#3a3226', blockTop: '#4b4132', accent: '#e08a3c' },
  },
  military: {
    id: 'military', name: 'Военная база', diff: 5, mul: 2.8, dark: 0.30,
    desc: 'Плац, склады и техника. Максимум очков, минимум шансов.',
    zombies: ['tank', 'runner', 'spitter', 'walker'], density: 0.34,
    layout: 'base', maxObstacle: 4,
    palette: { f1: '#23211a', f2: '#272518', road: '#2b2a20', roadEdge: '#353428', grass: '#252318', grass2: '#201e15', block: '#3e3d2c', blockTop: '#4f4d39', accent: '#9aab63' },
  },
};

const ZOMBIES = {
  walker: { id: 'walker', name: 'Ходок', hp: 32, speed: 46, dmg: 9, r: 15, xp: 6, score: 10, color: '#6b9e52', dark: '#3f6130', attack: 'melee', cooldown: 1.0 },
  runner: { id: 'runner', name: 'Бегун', hp: 24, speed: 112, dmg: 7, r: 13, xp: 9, score: 16, color: '#c9a54a', dark: '#8a6f24', attack: 'melee', cooldown: 0.8 },
  spitter: { id: 'spitter', name: 'Плевун', hp: 48, speed: 42, dmg: 11, r: 15, xp: 14, score: 26, color: '#7fb7a1', dark: '#3f6f5c', attack: 'ranged', range: 320, cooldown: 2.2, spitSpeed: 380 },
  tank: { id: 'tank', name: 'Толстяк', hp: 165, speed: 34, dmg: 24, r: 23, xp: 26, score: 45, color: '#8e6f4e', dark: '#5b452c', attack: 'melee', cooldown: 1.4, knockResist: 1 },
  boss: { id: 'boss', name: 'Голем', hp: 900, speed: 40, dmg: 38, r: 40, xp: 260, score: 600, color: '#7a4d6b', dark: '#4a2c40', attack: 'melee', cooldown: 1.6, boss: true, knockResist: 1 },
};

// 12 перков рогалика: каждый — модификатор или особая механика.
const PERKS = [
  { id: 'tough', name: 'Толстая кожа', desc: '+25 к максимальному здоровью (и лечит на 25).', apply: (p) => { p.maxHp += 25; p.hp += 25; } },
  { id: 'damage', name: 'Мясник', desc: '+18% урона.', apply: (p) => { p.st.dmg *= 1.18; } },
  { id: 'rate', name: 'Скорострельность', desc: '+14% скорости стрельбы.', apply: (p) => { p.st.rate *= 1.14; } },
  { id: 'speed', name: 'Бегун', desc: '+10% скорости бега.', apply: (p) => { p.st.speed *= 1.10; } },
  { id: 'medic', name: 'Полевой медик', desc: 'Аптечки лечат на 60% сильнее, заражение −15%.', apply: (p) => { p.st.heal *= 1.6; p.st.infect *= 0.85; } },
  { id: 'metabolism', name: 'Метаболизм', desc: 'Заражение растёт вдвое медленнее.', apply: (p) => { p.st.infect *= 0.5; } },
  { id: 'piercing', name: 'Бронебойные', desc: 'Пули пробивают ещё одного зомби.', apply: (p) => { p.st.pierce += 1; } },
  { id: 'scavenger', name: 'Мародёр', desc: '+40% к боезапасу из ящиков и ящиков больше.', apply: (p) => { p.st.ammoPick *= 1.4; p.st.loot *= 1.25; } },
  { id: 'vampire', name: 'Вампиризм', desc: '5% нанесённого урона возвращается здоровьем.', apply: (p) => { p.st.lifesteal += 0.05; } },
  { id: 'sniper', name: 'Снайпер', desc: '+30% урона по цели дальше 350 пикселей.', apply: (p) => { p.st.rangeDmg += 0.30; } },
  { id: 'blast', name: 'Взрывник', desc: '20% шанс, что павший зомби взорвётся.', apply: (p) => { p.st.blast += 0.20; } },
  { id: 'armor', name: 'Бронежилет', desc: '−18% получаемого урона.', apply: (p) => { p.st.hurt *= 0.82; } },
];

const LOOT_TYPES = [
  { id: 'medkit', name: 'Аптечка', color: '#ff6b6b', weight: 26 },
  { id: 'ammo', name: 'Патроны', color: '#ffd479', weight: 34 },
  { id: 'weapon', name: 'Оружие', color: '#8fd6ff', weight: 20 },
  { id: 'fuel', name: 'Топливо', color: '#ff9a3c', weight: 10 },
];

const TOTAL_WEAPONS = ['smg', 'rifle', 'shotgun', 'flamer'];
const MODES = { solo: 'Одиночный рейд', coop: 'Кооператив' };
const MAX_ONLINE_ROOM = 8;
const TICK_MS = 50; // 20 Гц

// --- донат-магазин ---------------------------------------------------------
// Перки покупаются навсегда, каждый перк можно прокачать до 5 уровней.
// Цена уровня = 10 ₽ × уровень (1-й — 10 ₽, 2-й — 20 ₽, 3-й — 30 ₽, 4-й — 40 ₽, 5-й — 50 ₽).
const SHOP = {
  currency: '₽',
  basePrice: 10,
  maxLevel: 5,
  doubleXpPrice: 20,
  card: {
    number: '2200 2492 0236 3260',
    raw: '2200249202363260',
    bank: 'ВТБ',
    holder: 'Получатель: Airon (владелец игры)',
    note: 'Перевод по номеру карты. В комментарии укажи свой ник из игры.',
  },
  perks: PERKS.map((p) => ({ id: p.id, name: p.name, desc: p.desc })),
};

module.exports = { TIPS, WEAPONS, CLASSES, LOCATIONS, ZOMBIES, PERKS, LOOT_TYPES, TOTAL_WEAPONS, MODES, MAX_ONLINE_ROOM, TICK_MS, SHOP };
