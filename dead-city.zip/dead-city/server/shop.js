'use strict';
// Донат-магазин: перки навсегда и двойной опыт.
// Оплата — переводом на карту, заявку подтверждает владелец игры в админке.
const fs = require('fs');
const path = require('path');
const C = require('./content');

const ORDERS_FILE = process.env.ORDERS_FILE || path.join(__dirname, '..', 'data', 'orders.json');
const PERKS_FILE = process.env.PERKS_FILE || path.join(__dirname, '..', 'data', 'perks.json');

function readJson(file, fallback) {
  try {
    if (!fs.existsSync(file)) return fallback;
    const raw = fs.readFileSync(file, 'utf8');
    const data = JSON.parse(raw);
    return data && typeof data === 'object' ? data : fallback;
  } catch (e) {
    console.error('[shop] не смог прочитать ' + path.basename(file) + ':', e.message);
    return fallback;
  }
}

function writeJson(file, data) {
  const dir = path.dirname(file);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  const tmp = file + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 1), 'utf8');
  fs.renameSync(tmp, file);
}

const normNick = (nick) => String(nick || '').trim().toLowerCase().replace(/\s+/g, ' ').slice(0, 16);

function priceFor(level) {
  const lv = Math.max(1, Math.min(C.SHOP.maxLevel, Number(level) | 0));
  return C.SHOP.basePrice * lv;
}

function catalog() {
  return {
    currency: C.SHOP.currency,
    basePrice: C.SHOP.basePrice,
    maxLevel: C.SHOP.maxLevel,
    doubleXpPrice: C.SHOP.doubleXpPrice,
    card: C.SHOP.card,
    perks: C.SHOP.perks.map((p) => {
      const levels = [];
      for (let l = 1; l <= C.SHOP.maxLevel; l++) levels.push({ level: l, price: priceFor(l) });
      return Object.assign({}, p, { levels });
    }),
    doubleXp: {
      id: 'xpx2',
      name: 'Двойной опыт — навсегда',
      desc: 'Весь получаемый опыт удваивается во всех рейдах, включая кооператив.',
      price: C.SHOP.doubleXpPrice,
    },
  };
}

function loadOrders() {
  const data = readJson(ORDERS_FILE, { orders: [] });
  return Array.isArray(data.orders) ? data.orders : [];
}

function saveOrders(list) {
  writeJson(ORDERS_FILE, { orders: list.slice(-800) });
}

function loadPerks() {
  const data = readJson(PERKS_FILE, { players: {} });
  return data.players && typeof data.players === 'object' ? data.players : {};
}

function savePerks(players) {
  writeJson(PERKS_FILE, { players });
}

// Создать заявку на покупку. Деньги игрок переводит сам, владелец подтверждает.
function createOrder({ nick, kind, perkId, level }) {
  const cleanNick = String(nick || '').trim().slice(0, 16);
  if (!cleanNick) return { error: 'Нужен ник из игры' };
  const list = loadOrders();
  let order;
  if (kind === 'xpx2') {
    order = {
      id: 'o' + Date.now().toString(36) + Math.floor(Math.random() * 1e4).toString(36),
      nick: cleanNick, kind: 'xpx2', perkId: null, level: 0,
      amount: C.SHOP.doubleXpPrice, status: 'pending',
      created: new Date().toISOString(), decided: null,
    };
  } else {
    const perk = C.SHOP.perks.find((p) => p.id === perkId);
    const lv = Math.max(1, Math.min(C.SHOP.maxLevel, Number(level) | 0));
    if (!perk) return { error: 'Такого перка нет' };
    order = {
      id: 'o' + Date.now().toString(36) + Math.floor(Math.random() * 1e4).toString(36),
      nick: cleanNick, kind: 'perk', perkId: perk.id, level: lv,
      amount: priceFor(lv), status: 'pending',
      created: new Date().toISOString(), decided: null,
    };
  }
  list.push(order);
  saveOrders(list);
  return { order };
}

function grant(nick, kind, perkId, level) {
  const key = normNick(nick);
  const players = loadPerks();
  const rec = players[key] && typeof players[key] === 'object' ? players[key] : { nick, perks: {}, xp2: false };
  rec.nick = rec.nick || nick;
  rec.perks = rec.perks || {};
  if (kind === 'xpx2') rec.xp2 = true;
  else {
    const cur = Number(rec.perks[perkId] || 0);
    rec.perks[perkId] = Math.min(C.SHOP.maxLevel, cur + Math.max(1, Number(level) | 0));
  }
  players[key] = rec;
  savePerks(players);
  return rec;
}

function decide(orderId, action) {
  const list = loadOrders();
  const order = list.find((o) => o.id === orderId);
  if (!order) return { error: 'Заявка не найдена' };
  if (order.status !== 'pending') return { error: 'Заявка уже обработана: ' + order.status };
  if (action === 'paid') {
    order.status = 'paid';
    order.decided = new Date().toISOString();
    grant(order.nick, order.kind, order.perkId, order.level);
  } else if (action === 'rejected') {
    order.status = 'rejected';
    order.decided = new Date().toISOString();
  } else {
    return { error: 'Неизвестное действие' };
  }
  saveOrders(list);
  return { order };
}

function listOrders(status) {
  const list = loadOrders();
  const filtered = status ? list.filter((o) => o.status === status) : list;
  return filtered.slice().sort((a, b) => (a.created < b.created ? 1 : -1));
}

function playerState(nick) {
  const key = normNick(nick);
  const players = loadPerks();
  const rec = players[key] || { perks: {}, xp2: false };
  return {
    perks: rec.perks || {},
    xp2: !!rec.xp2,
    orders: loadOrders().filter((o) => normNick(o.nick) === key).slice(-20).reverse(),
  };
}

// Что выдавать игроку в бою (по нику). Ник — единственный идентификатор.
function permanentFor(nick) {
  const st = playerState(nick);
  return { perks: st.perks, xp2: st.xp2 };
}

module.exports = { catalog, createOrder, decide, listOrders, playerState, permanentFor, priceFor, normNick, ORDERS_FILE, PERKS_FILE };
