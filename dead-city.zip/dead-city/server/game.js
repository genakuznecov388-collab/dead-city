'use strict';
// Движок мира: авторитетная симуляция на сервере, тик 20 Гц.
const C = require('./content');
const { makeRng, newSeed } = require('./rng');
const MAP = require('./map');

const { TILE, COLS, ROWS, W, H } = MAP;
const PR = 14;            // радиус игрока
const REVIVE_TIME = 3;    // сек на подъём товарища
const DOWN_TIME = 25;     // сек до смерти в отключке
const FLOW_EVERY = 0.25;  // как часто пересчитываем поле путей (сек)

const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
const dist2 = (ax, ay, bx, by) => { const dx = ax - bx, dy = ay - by; return dx * dx + dy * dy; };
const round = (v) => Math.round(v);

function tileAt(map, cx, cy) {
  if (cx < 0 || cy < 0 || cx >= COLS || cy >= ROWS) return 1;
  return map[cy * COLS + cx];
}

function circleFree(map, x, y, r) {
  const x0 = Math.floor((x - r) / TILE), x1 = Math.floor((x + r) / TILE);
  const y0 = Math.floor((y - r) / TILE), y1 = Math.floor((y + r) / TILE);
  for (let cy = y0; cy <= y1; cy++) {
    for (let cx = x0; cx <= x1; cx++) {
      if (tileAt(map, cx, cy) === 0) continue;
      const rx = cx * TILE, ry = cy * TILE;
      const nx = clamp(x, rx, rx + TILE), ny = clamp(y, ry, ry + TILE);
      const dx = x - nx, dy = y - ny;
      if (dx * dx + dy * dy < r * r) return false;
    }
  }
  return true;
}

// Есть ли прямая видимость между двумя точками (для «умных» зомби).
function lineClear(map, x0, y0, x1, y1) {
  const dx = x1 - x0, dy = y1 - y0;
  const len = Math.hypot(dx, dy);
  const steps = Math.ceil(len / 14);
  for (let i = 1; i <= steps; i++) {
    const t = i / steps;
    const x = x0 + dx * t, y = y0 + dy * t;
    if (tileAt(map, Math.floor(x / TILE), Math.floor(y / TILE)) !== 0) return false;
  }
  return true;
}

// Двигает сущность с учётом стен, маленькими шагами (не проскакивает сквозь угол).
function tryMove(map, e, dx, dy, r) {
  const steps = Math.max(1, Math.ceil(Math.max(Math.abs(dx), Math.abs(dy)) / 6));
  const sx = dx / steps, sy = dy / steps;
  for (let i = 0; i < steps; i++) {
    if (sx && circleFree(map, e.x + sx, e.y, r)) e.x += sx;
    if (sy && circleFree(map, e.x, e.y + sy, r)) e.y += sy;
  }
  e.x = clamp(e.x, r, W - r);
  e.y = clamp(e.y, r, H - r);
}

class Game {
  constructor({ code, location, seed, mode, maxPlayers }) {
    this.code = code;
    this.location = C.LOCATIONS[location] || C.LOCATIONS.suburb;
    this.seed = seed || newSeed();
    this.rng = makeRng(this.seed);
    this.mode = mode === 'coop' ? 'coop' : 'solo';
    this.maxPlayers = this.mode === 'coop' ? (maxPlayers || C.MAX_ONLINE_ROOM) : 1;
    const gen = MAP.generateMap(this.location, this.rng);
    this.map = gen.map;
    this.floor = gen.floor;
    this.decor = gen.decor;
    this.players = new Map();
    this.zombies = [];
    this.bullets = [];
    this.loot = [];
    this.turrets = [];
    this.spawnQueue = [];
    this.spawnTimer = 0;
    this.wave = 0;
    this.phase = 'lobby';       // lobby | break | active | over
    this.nextIn = 0;
    this.time = 0;
    this.idc = 1;
    this.lootTimer = 20;
    this.onDeath = null;        // колбэк от server.js (запись в лидерборд)
    this.hostId = null;
    // поле путей: от игроков через свободные тайлы (умные зомби)
    this.dist = new Int32Array(COLS * ROWS);
    this.fx = new Int8Array(COLS * ROWS);
    this.fy = new Int8Array(COLS * ROWS);
    this.flowTimer = 0;
    this.flowReady = false;
  }

  // --- навигация -----------------------------------------------------------
  buildFlow() {
    const N = COLS * ROWS;
    this.dist.fill(-1);
    const queue = [];
    for (const p of this.players.values()) {
      if (p.dead) continue;
      const cx = clamp(Math.floor(p.x / TILE), 0, COLS - 1);
      const cy = clamp(Math.floor(p.y / TILE), 0, ROWS - 1);
      const i = cy * COLS + cx;
      if (this.map[i] !== 0 || this.dist[i] === 0) continue;
      this.dist[i] = 0;
      queue.push(i);
    }
    for (let head = 0; head < queue.length; head++) {
      const i = queue[head];
      const d = this.dist[i];
      const cx = i % COLS, cy = (i - cx) / COLS;
      if (cx > 0 && this.map[i - 1] === 0 && this.dist[i - 1] < 0) { this.dist[i - 1] = d + 1; queue.push(i - 1); }
      if (cx < COLS - 1 && this.map[i + 1] === 0 && this.dist[i + 1] < 0) { this.dist[i + 1] = d + 1; queue.push(i + 1); }
      if (cy > 0 && this.map[i - COLS] === 0 && this.dist[i - COLS] < 0) { this.dist[i - COLS] = d + 1; queue.push(i - COLS); }
      if (cy < ROWS - 1 && this.map[i + COLS] === 0 && this.dist[i + COLS] < 0) { this.dist[i + COLS] = d + 1; queue.push(i + COLS); }
    }
    // направление «вниз по градиенту» для каждого свободного тайла
    for (let cy = 0; cy < ROWS; cy++) {
      for (let cx = 0; cx < COLS; cx++) {
        const i = cy * COLS + cx;
        if (this.map[i] !== 0 || this.dist[i] < 0) { this.fx[i] = 0; this.fy[i] = 0; continue; }
        let best = this.dist[i], bx = 0, by = 0;
        for (let dy = -1; dy <= 1; dy++) {
          for (let dx = -1; dx <= 1; dx++) {
            if (!dx && !dy) continue;
            const nx = cx + dx, ny = cy + dy;
            if (nx < 0 || ny < 0 || nx >= COLS || ny >= ROWS) continue;
            const ni = ny * COLS + nx;
            if (this.map[ni] !== 0 || this.dist[ni] < 0) continue;
            if (dx && dy && (this.map[cy * COLS + nx] !== 0 || this.map[ny * COLS + cx] !== 0)) continue; // не режем угол
            if (this.dist[ni] < best) { best = this.dist[ni]; bx = dx; by = dy; }
          }
        }
        this.fx[i] = bx; this.fy[i] = by;
      }
    }
    this.flowReady = true;
    this.flowTimer = FLOW_EVERY;
  }

  // Свободное место для спавна: вне стен с учётом радиуса и достижимости от игроков.
  freeSpot(minDistFromPlayers = 0, radius = PR + 3, needReachable = false) {
    for (let i = 0; i < 600; i++) {
      const x = this.rng.float(TILE * 1.5, W - TILE * 1.5);
      const y = this.rng.float(TILE * 1.5, H - TILE * 1.5);
      if (!circleFree(this.map, x, y, radius)) continue;
      const cx = clamp(Math.floor(x / TILE), 0, COLS - 1);
      const cy = clamp(Math.floor(y / TILE), 0, ROWS - 1);
      // тайл и все соседи свободны — сущность не «вмуруется» в препятствие
      let boxed = false;
      for (let dy = -1; dy <= 1 && !boxed; dy++) {
        for (let dx = -1; dx <= 1; dx++) {
          if (tileAt(this.map, cx + dx, cy + dy) !== 0) { boxed = true; break; }
        }
      }
      if (boxed) continue;
      if (needReachable && (!this.flowReady || this.dist[cy * COLS + cx] < 0)) continue;
      if (minDistFromPlayers > 0) {
        let far = true;
        for (const p of this.players.values()) {
          if (p.dead) continue;
          if (dist2(p.x, p.y, x, y) < minDistFromPlayers * minDistFromPlayers) { far = false; break; }
        }
        if (!far) continue;
      }
      return { x, y };
    }
    return { x: W / 2, y: H / 2 };
  }

  addPlayer(id, nick, clsId, permanent) {
    const cls = C.CLASSES[clsId] || C.CLASSES.soldier;
    const spot = this.players.size === 0 && this.mode === 'solo' ? { x: W / 2, y: H / 2 } : this.freeSpot(90);
    if (!circleFree(this.map, spot.x, spot.y, PR + 2)) { spot.x = W / 2; spot.y = H / 2; }
    const p = {
      id, nick, cls: cls.id, x: spot.x, y: spot.y, ang: 0,
      hp: cls.hp, maxHp: cls.hp, inf: 0,
      level: 1, xp: 0, xpNeed: 40, score: 0, kills: 0,
      dead: false, downed: 0, reviveBy: null, reviveT: 0, revives: 0,
      weapon: cls.weapon, weapons: [cls.weapon], ammo: Object.assign({ heavy: 0, light: 0, fuel: 0 }, cls.ammo),
      cd: 0, abilityCd: 0, abilityOn: 0, ability: null, spawnProt: 2,
      dashT: 0, dashAng: 0, immune: 0,
      perks: [], offer: null, permanent: {},
      st: {
        dmg: cls.dmg, rate: cls.rate, speed: cls.speed, xp: cls.xp, hurt: cls.hurt,
        infect: 1, pierce: 0, ammoPick: 1, loot: 1, lifesteal: 0, rangeDmg: 0, blast: 0, heal: 1,
      },
      input: { up: false, down: false, left: false, right: false, ax: 0, ay: 0, shoot: false, revive: false },
      prevShoot: false,
    };
    // донат-перки: применяются навсегда при входе в игру
    if (permanent && typeof permanent === 'object') {
      for (const [perkId, level] of Object.entries(permanent.perks || {})) {
        const def = C.PERKS.find((x) => x.id === perkId);
        if (!def) continue;
        const times = Math.max(0, Math.min(C.SHOP.maxLevel, Number(level) || 0));
        for (let i = 0; i < times; i++) def.apply(p);
        p.permanent[perkId] = times;
      }
      if (permanent.xp2) { p.st.xp *= 2; p.permanent.xp2 = true; }
    }
    this.players.set(id, p);
    if (!this.hostId) this.hostId = id;
    if (!this.flowReady) this.buildFlow();
    return p;
  }

  removePlayer(id) {
    this.players.delete(id);
    if (this.hostId === id) this.hostId = this.players.size ? [...this.players.keys()][0] : null;
  }

  setInput(id, inp) {
    const p = this.players.get(id);
    if (!p || !inp) return;
    const b = (v) => v === true;
    p.input.up = b(inp.up); p.input.down = b(inp.down);
    p.input.left = b(inp.left); p.input.right = b(inp.right);
    p.input.shoot = b(inp.shoot); p.input.revive = b(inp.revive);
    if (typeof inp.ax === 'number' && isFinite(inp.ax)) p.input.ax = inp.ax;
    if (typeof inp.ay === 'number' && isFinite(inp.ay)) p.input.ay = inp.ay;
  }

  useAbility(id) {
    const p = this.players.get(id);
    if (!p || p.dead || p.downed > 0 || p.abilityCd > 0) return;
    const ab = (C.CLASSES[p.cls] || {}).ability;
    if (!ab) return;
    p.abilityCd = ab.cd;
    p.abilityOn = ab.dur;
    p.ability = ab.id;
    if (ab.id === 'flame') {
      for (const z of this.zombies) {
        if (dist2(z.x, z.y, p.x, p.y) < 210 * 210) { z.burn = Math.max(z.burn, ab.dur); z.burnDps = 26; }
      }
      for (let i = 0; i < 14; i++) this.bullets.push({
        x: p.x, y: p.y, vx: Math.cos((i / 14) * Math.PI * 2) * 260, vy: Math.sin((i / 14) * Math.PI * 2) * 260,
        dmg: 0, team: 'fx', life: 0.4, r: 10, color: '#ff7a2f',
      });
    } else if (ab.id === 'flash') {
      for (const z of this.zombies) {
        if (dist2(z.x, z.y, p.x, p.y) < 260 * 260) z.stun = Math.max(z.stun, ab.dur);
      }
    } else if (ab.id === 'turret') {
      const spot = circleFree(this.map, p.x, p.y, PR + 2) ? { x: p.x, y: p.y } : this.freeSpot(0);
      this.turrets.push({ id: this.idc++, x: spot.x, y: spot.y, owner: p.id, until: this.time + ab.dur, cd: 0, hp: 260 });
    } else if (ab.id === 'dash') {
      p.dashT = ab.dur;
      p.dashAng = p.ang;
      p.immune = 1.0;
    }
  }

  swapWeapon(id, index) {
    const p = this.players.get(id);
    if (!p || p.dead) return;
    const w = p.weapons[index];
    if (w) { p.weapon = w; p.cd = 0.25; }
  }

  choosePerk(id, perkId) {
    const p = this.players.get(id);
    if (!p || !p.offer) return;
    const opt = p.offer.options.find((o) => o.id === perkId);
    if (!opt) return;
    const real = C.PERKS.find((x) => x.id === perkId);
    if (real) { real.apply(p); p.perks.push(perkId); }
    else if (perkId === 'extra_hp') { p.maxHp += 30; p.hp += 30; p.perks.push('extra_hp'); }
    p.offer = null;
    this.grantLevels(p);
    return true;
  }

  rollOffer(p) {
    const pool = C.PERKS.filter((x) => !p.perks.includes(x.id));
    const options = [];
    const copy = pool.slice();
    while (options.length < 3 && copy.length) {
      options.push(copy.splice(Math.floor(this.rng.next() * copy.length), 1)[0]);
    }
    if (!options.length) options.push({ id: 'extra_hp', name: 'Закалка', desc: '+30 к здоровью.' });
    return { level: p.level, options };
  }

  grantLevels(p) {
    let guard = 0;
    while (p.xp >= p.xpNeed && guard++ < 30) {
      p.xp -= p.xpNeed;
      p.level++;
      p.xpNeed = Math.round(40 * Math.pow(p.level, 1.38));
      p.offer = this.rollOffer(p);
      p.score += 25 * Math.round(this.location.mul);
    }
  }

  // --- волны ---------------------------------------------------------------
  start() {
    if (this.phase === 'active' || this.phase === 'break') return false;
    this.wave = 0;
    this.phase = 'break';
    this.nextIn = 5;
    return true;
  }

  startWave() {
    this.wave++;
    const loc = this.location;
    const playersFactor = this.mode === 'coop' ? 1 + 0.32 * Math.max(0, this.players.size - 1) : 1;
    const n = Math.round((5 + this.wave * 3.1) * (0.55 + loc.diff * 0.25) * playersFactor);
    this.spawnQueue = [];
    for (let i = 0; i < n; i++) this.spawnQueue.push(this.rng.pick(loc.zombies));
    if (this.wave % 5 === 0) this.spawnQueue.push('boss');
    this.spawnTimer = 0;
    this.phase = 'active';
    this.lootTimer = Math.min(this.lootTimer, 8);
  }

  endWave() {
    this.phase = 'break';
    this.nextIn = 6;
    const bonus = Math.round(45 * this.wave * this.location.mul);
    for (const p of this.players.values()) {
      if (p.dead) continue;
      p.score += bonus;
      p.hp = Math.min(p.maxHp, p.hp + 12);
      p.ammo.light += 20; p.ammo.heavy += 12;
    }
  }

  spawnZombie(type) {
    const base = C.ZOMBIES[type] || C.ZOMBIES.walker;
    // спавн только на свободном пятачке, с учётом размера зомби и достижимости от игроков
    const spot = this.freeSpot(560, base.r + 6, true);
    const hpMul = (1 + (this.wave - 1) * 0.135) * (1 + (this.location.diff - 1) * 0.13);
    const dmgMul = (1 + (this.wave - 1) * 0.06) * (1 + (this.location.diff - 1) * 0.1);
    this.zombies.push({
      id: this.idc++, type: base.id,
      x: spot.x, y: spot.y, r: base.r,
      hp: Math.round(base.hp * hpMul), maxHp: Math.round(base.hp * hpMul),
      speed: base.speed * (1 + (this.wave - 1) * 0.012),
      dmg: base.dmg * dmgMul,
      atkCd: this.rng.float(0, 1), stun: 0, burn: 0, burnDps: 0,
      kx: 0, ky: 0, boss: !!base.boss, ranged: base.attack === 'ranged',
      stuck: 0,
    });
  }

  // --- урон ----------------------------------------------------------------
  damageZombie(z, dmg, src, knock, fromRange) {
    let d = dmg * src.st.dmg;
    if (src.st.rangeDmg > 0 && fromRange > 350) d *= 1 + src.st.rangeDmg;
    if (src.abilityOn > 0 && src.ability === 'burst') d *= 1.5;
    if (src.abilityOn > 0 && src.ability === 'adrenaline') d *= 1.2;
    z.hp -= d;
    if (src.st.lifesteal > 0) src.hp = Math.min(src.maxHp, src.hp + d * src.st.lifesteal);
    if (knock && !z.boss) { const a = Math.atan2(z.y - src.y, z.x - src.x); z.kx += Math.cos(a) * 180; z.ky += Math.sin(a) * 180; }
    if (z.hp <= 0) this.killZombie(z, src);
  }

  killZombie(z, src) {
    const i = this.zombies.indexOf(z);
    if (i >= 0) this.zombies.splice(i, 1);
    const base = C.ZOMBIES[z.type] || C.ZOMBIES.walker;
    if (src && !src.dead) {
      src.kills++;
      src.score += Math.round(base.score * this.location.mul);
      src.xp += Math.round(base.xp * src.st.xp);
      this.grantLevels(src);
      if (src.st.blast > 0 && this.rng.chance(src.st.blast)) {
        for (const o of this.zombies.slice()) {
          if (dist2(o.x, o.y, z.x, z.y) < 120 * 120) this.damageZombie(o, 45, src, 0, 0);
        }
        this.bullets.push({ x: z.x, y: z.y, vx: 0, vy: 0, dmg: 0, team: 'fx', life: 0.25, r: 60, color: '#ffb347' });
      }
    }
    if (this.rng.chance((z.boss ? 1 : 0.16) * (src ? src.st.loot : 1))) this.dropLoot(z.x, z.y, z.boss ? 3 : 1);
  }

  damagePlayer(p, dmg, infect) {
    if (p.dead || p.downed > 0 || p.spawnProt > 0 || p.immune > 0) return;
    p.hp -= dmg * p.st.hurt;
    p.inf = Math.min(100, p.inf + (infect || 0) * p.st.infect);
    if (p.hp <= 0) {
      p.hp = 0;
      const alone = this.players.size < 2;
      if (alone) this.killPlayer(p);
      else { p.downed = DOWN_TIME; }
    }
  }

  killPlayer(p) {
    p.dead = true; p.downed = 0;
    if (typeof this.onDeath === 'function') {
      try { this.onDeath(p, this); } catch (e) { console.error('[game] onDeath:', e.message); }
    }
  }

  dropLoot(x, y, count) {
    for (let i = 0; i < count; i++) {
      const roll = this.rng.next() * 100;
      let acc = 0, type = 'ammo';
      for (const lt of C.LOOT_TYPES) { acc += lt.weight; if (roll <= acc) { type = lt.id; break; } }
      const spot = circleFree(this.map, x, y, 12) ? { x, y } : this.freeSpot(0);
      this.loot.push({ id: this.idc++, x: spot.x + this.rng.float(-14, 14), y: spot.y + this.rng.float(-14, 14), type });
    }
  }

  pickup(p) {
    for (const item of this.loot.slice()) {
      if (dist2(item.x, item.y, p.x, p.y) > 30 * 30) continue;
      const idx = this.loot.indexOf(item);
      if (idx >= 0) this.loot.splice(idx, 1);
      if (item.type === 'medkit') { p.hp = Math.min(p.maxHp, p.hp + 45 * p.st.heal); p.inf = Math.max(0, p.inf - 45 * p.st.heal); }
      else if (item.type === 'ammo') { p.ammo.light += Math.round(24 * p.st.ammoPick); p.ammo.heavy += Math.round(14 * p.st.ammoPick); }
      else if (item.type === 'fuel') { p.ammo.fuel += Math.round(45 * p.st.ammoPick); }
      else if (item.type === 'weapon') {
        const w = this.rng.pick(C.TOTAL_WEAPONS);
        if (!p.weapons.includes(w)) p.weapons.push(w);
        if (w === 'flamer') p.ammo.fuel += Math.round(70 * p.st.ammoPick);
        else if (w === 'smg') p.ammo.light += Math.round(60 * p.st.ammoPick);
        else p.ammo.heavy += Math.round(30 * p.st.ammoPick);
        p.weapon = w;
      }
    }
  }

  // --- стрельба ------------------------------------------------------------
  fire(p, dt) {
    if (p.cd > 0) p.cd -= dt;
    if (p.dead || p.downed > 0) return;
    const w = C.WEAPONS[p.weapon] || C.WEAPONS.pistol;
    const wantShoot = p.input.shoot;

    if (w.melee) {
      if (wantShoot && !p.prevShoot && p.cd <= 0) {
        p.cd = w.rate / p.st.rate;
        const reach = w.melee;
        for (const z of this.zombies.slice()) {
          if (dist2(z.x, z.y, p.x, p.y) > (reach + z.r) * (reach + z.r)) continue;
          const a = Math.atan2(z.y - p.y, z.x - p.x);
          let da = Math.abs(((a - p.ang + Math.PI * 3) % (Math.PI * 2)) - Math.PI);
          if (da <= 1.0) this.damageZombie(z, w.dmg, p, w.knock, 0);
        }
        this.bullets.push({ x: p.x + Math.cos(p.ang) * 30, y: p.y + Math.sin(p.ang) * 30, vx: 0, vy: 0, dmg: 0, team: 'fx', life: 0.12, r: 34, color: '#ffffff' });
      }
      p.prevShoot = wantShoot;
      return;
    }

    if (!wantShoot) { p.prevShoot = false; return; }
    if (!w.auto && p.prevShoot) return;
    if (p.cd > 0) return;

    const burst = p.abilityOn > 0 && p.ability === 'burst';
    const free = w.ammo === 'inf' || burst;
    if (!free) {
      if ((p.ammo[w.ammo] || 0) <= 0) {
        // нет патронов — откат на пистолет
        if (p.weapon !== 'pistol') { p.weapon = 'pistol'; p.cd = 0.35; }
        p.prevShoot = wantShoot;
        return;
      }
      p.ammo[w.ammo]--;
    }
    p.cd = w.rate / (p.st.rate * (burst ? 2 : 1));
    p.prevShoot = true;

    const shots = w.shots || 1;
    for (let i = 0; i < (w.pellets || 1); i++) {
      const spread = (this.rng.next() - 0.5) * 2 * w.spread;
      const ang = p.ang + spread;
      this.bullets.push({
        x: p.x + Math.cos(p.ang) * 20, y: p.y + Math.sin(p.ang) * 20,
        vx: Math.cos(ang) * w.speed, vy: Math.sin(ang) * w.speed,
        dmg: w.dmg, team: 'player', owner: p.id, pierce: p.st.pierce + (w.pierce || 0),
        life: w.life || 1.1, r: w.bulletR || 3, color: w.color,
        knock: w.knock || 0, fire: !!w.fire, hit: [],
      });
    }
  }

  // --- тик -----------------------------------------------------------------
  tick(dtMs) {
    const dt = Math.min(0.1, dtMs / 1000);
    if (this.phase === 'over') return;
    this.time += dt;

    // волны
    if (this.phase === 'lobby') {
      // ждём старта от хоста
    } else if (this.phase === 'break') {
      this.nextIn -= dt;
      if (this.nextIn <= 0) this.startWave();
    } else if (this.phase === 'active') {
      this.spawnTimer -= dt;
      if (this.spawnQueue.length && this.spawnTimer <= 0) {
        const batch = Math.min(this.spawnQueue.length, 3);
        for (let i = 0; i < batch; i++) this.spawnZombie(this.spawnQueue.shift());
        this.spawnTimer = 0.8;
      }
      if (!this.spawnQueue.length && !this.zombies.length) this.endWave();
    }

    // поле путей для «умных» зомби (пересчёт 4 раза в секунду)
    this.flowTimer -= dt;
    if (!this.flowReady || this.flowTimer <= 0) this.buildFlow();

    // игроки
    for (const p of this.players.values()) {
      if (p.spawnProt > 0) p.spawnProt -= dt;
      if (p.abilityCd > 0) p.abilityCd -= dt;
      if (p.abilityOn > 0) p.abilityOn -= dt;
      if (p.immune > 0) p.immune -= dt;
      if (p.dead) continue;

      if (p.downed > 0) {
        p.downed -= dt;
        if (p.downed <= 0) { this.killPlayer(p); continue; }
        // подъём товарища
        let helper = null;
        for (const o of this.players.values()) {
          if (o.id === p.id || o.dead || o.downed > 0) continue;
          if (o.input.revive && dist2(o.x, o.y, p.x, p.y) < 70 * 70) { helper = o; break; }
        }
        if (helper) {
          p.reviveT += dt * 1.0;
          if (p.reviveT >= REVIVE_TIME) {
            p.downed = 0; p.reviveT = 0; p.revives++;
            p.hp = Math.round(p.maxHp * 0.45);
            p.inf = Math.max(0, p.inf - 30);
            p.spawnProt = 1.5;
          }
        } else p.reviveT = Math.max(0, p.reviveT - dt * 0.5);
        continue;
      }

      // рывок спортсмена: летит вперёд, обычное управление в это время не действует
      if (p.dashT > 0) {
        p.dashT -= dt;
        const dashSpeed = 840;
        tryMove(this.map, p, Math.cos(p.dashAng) * dashSpeed * dt, Math.sin(p.dashAng) * dashSpeed * dt, PR);
        p.ang = Math.atan2(p.input.ay - p.y, p.input.ax - p.x);
        this.fire(p, dt);
        continue;
      }

      // движение
      let dx = (p.input.right ? 1 : 0) - (p.input.left ? 1 : 0);
      let dy = (p.input.down ? 1 : 0) - (p.input.up ? 1 : 0);
      if (dx || dy) {
        const len = Math.hypot(dx, dy);
        dx /= len; dy /= len;
      }
      let speed = p.st.speed;
      if (p.abilityOn > 0 && p.ability === 'adrenaline') speed *= 1.6;
      if (p.inf >= 100) speed *= 0.82;
      tryMove(this.map, p, dx * speed * dt, dy * speed * dt, PR);

      // прицел
      p.ang = Math.atan2(p.input.ay - p.y, p.input.ax - p.x);

      // заражение на 100% подтачивает здоровье
      if (p.inf >= 100) { p.hp -= 3.5 * dt; if (p.hp <= 0) { p.hp = 0; this.killPlayer(p); continue; } }

      this.fire(p, dt);
      if (this.phase === 'active' || this.phase === 'break') this.pickup(p);
    }

    // зомби
    for (const z of this.zombies.slice()) {
      if (z.stun > 0) { z.stun -= dt; }
      if (z.burn > 0) {
        z.burn -= dt;
        z.hp -= z.burnDps * dt;
        if (z.hp <= 0) { this.killZombie(z, [...this.players.values()].find((p) => !p.dead) || null); continue; }
      }
      // отбрасывание
      if (z.kx || z.ky) {
        tryMove(this.map, z, z.kx * dt, z.ky * dt, z.r);
        z.kx *= 0.86; z.ky *= 0.86;
        if (Math.abs(z.kx) < 5) z.kx = 0;
        if (Math.abs(z.ky) < 5) z.ky = 0;
      }
      if (z.stun > 0) continue;

      // цель — ближайший живой игрок
      let target = null, best = Infinity;
      for (const p of this.players.values()) {
        if (p.dead) continue;
        const d = dist2(p.x, p.y, z.x, z.y);
        if (d < best) { best = d; target = p; }
      }
      if (!target) continue;
      const d = Math.sqrt(best);
      const reach = z.r + PR + 4;
      if (d > reach) {
        const sp = z.speed * dt;
        let dirx, diry;
        if (lineClear(this.map, z.x, z.y, target.x, target.y)) {
          const a = Math.atan2(target.y - z.y, target.x - z.x);
          dirx = Math.cos(a); diry = Math.sin(a);
        } else {
          // обход препятствий по полю путей
          const cx = clamp(Math.floor(z.x / TILE), 0, COLS - 1);
          const cy = clamp(Math.floor(z.y / TILE), 0, ROWS - 1);
          const i = cy * COLS + cx;
          let fdx = this.fx[i], fdy = this.fy[i];
          if (!fdx && !fdy) {
            const a = Math.atan2(target.y - z.y, target.x - z.x);
            fdx = Math.cos(a); fdy = Math.sin(a);
          }
          const flen = Math.hypot(fdx, fdy) || 1;
          dirx = fdx / flen; diry = fdy / flen;
        }
        const bx = z.x, by = z.y;
        tryMove(this.map, z, dirx * sp, diry * sp, z.r);
        // антизастревание: если почти не сдвинулся — шаг вбок
        if (Math.abs(z.x - bx) + Math.abs(z.y - by) < sp * 0.35) {
          z.stuck += dt;
          if (z.stuck > 0.35) {
            z.stuck = 0;
            const a = Math.atan2(diry, dirx) + (this.rng.chance(0.5) ? 1 : -1) * Math.PI / 2;
            tryMove(this.map, z, Math.cos(a) * sp * 2, Math.sin(a) * sp * 2, z.r);
          }
        } else z.stuck = 0;
      } else if (z.ranged) {
        z.atkCd -= dt;
        if (z.atkCd <= 0 && d < 340) {
          z.atkCd = 2.2;
          const a = Math.atan2(target.y - z.y, target.x - z.x);
          const base = C.ZOMBIES.spitter;
          this.bullets.push({
            x: z.x, y: z.y, vx: Math.cos(a) * base.spitSpeed, vy: Math.sin(a) * base.spitSpeed,
            dmg: z.dmg, team: 'zombie', life: 1.6, r: 6, color: '#9be89b', hit: [],
          });
        }
      } else {
        z.atkCd -= dt;
        if (z.atkCd <= 0) {
          z.atkCd = (C.ZOMBIES[z.type] || {}).cooldown || 1.2;
          this.damagePlayer(target, z.dmg, 6 + this.wave * 0.35);
        }
      }
    }

    // пули
    for (const b of this.bullets.slice()) {
      b.life -= dt;
      if (b.life <= 0) { this.bullets.splice(this.bullets.indexOf(b), 1); continue; }
      const sub = Math.max(1, Math.ceil(Math.hypot(b.vx, b.vy) * dt / 12));
      let gone = false;
      for (let s = 0; s < sub && !gone; s++) {
        b.x += (b.vx * dt) / sub; b.y += (b.vy * dt) / sub;
        if (b.x < 0 || b.y < 0 || b.x > W || b.y > H) { gone = true; break; }
        if (tileAt(this.map, Math.floor(b.x / TILE), Math.floor(b.y / TILE)) !== 0) { gone = true; break; }
        if (b.team === 'fx') continue;
        if (b.team === 'player') {
          for (const z of this.zombies.slice()) {
            if (b.hit.includes(z.id)) continue;
            if (dist2(z.x, z.y, b.x, b.y) > (z.r + b.r) * (z.r + b.r)) continue;
            const src = this.players.get(b.owner);
            b.hit.push(z.id);
            if (src) this.damageZombie(z, b.dmg, src, b.knock, Math.hypot(b.x - src.x, b.y - src.y));
            if (b.fire && this.zombies.includes(z)) { z.burn = Math.max(z.burn, 2.5); z.burnDps = Math.max(z.burnDps, 14); }
            if (b.pierce > 0) b.pierce--; else gone = true;
            break;
          }
        } else if (b.team === 'zombie') {
          for (const p of this.players.values()) {
            if (p.dead || p.downed > 0) continue;
            if (dist2(p.x, p.y, b.x, b.y) > (PR + b.r) * (PR + b.r)) continue;
            this.damagePlayer(p, b.dmg, 4 + this.wave * 0.2);
            gone = true; break;
          }
        }
      }
      if (gone) this.bullets.splice(this.bullets.indexOf(b), 1);
    }

    // турели
    for (const t of this.turrets.slice()) {
      if (this.time > t.until || t.hp <= 0) { this.turrets.splice(this.turrets.indexOf(t), 1); continue; }
      t.cd -= dt;
      if (t.cd > 0) continue;
      let best = null, bd = 430 * 430;
      for (const z of this.zombies) { const d = dist2(z.x, z.y, t.x, t.y); if (d < bd) { bd = d; best = z; } }
      if (!best) continue;
      t.cd = 0.42;
      const a = Math.atan2(best.y - t.y, best.x - t.x);
      this.bullets.push({ x: t.x, y: t.y, vx: Math.cos(a) * 900, vy: Math.sin(a) * 900, dmg: 16, team: 'player', owner: t.owner, pierce: 0, life: 0.8, r: 3, color: '#8fd6ff', knock: 0, hit: [] });
    }

    // лут со временем
    this.lootTimer -= dt;
    if (this.lootTimer <= 0 && this.loot.length < 14) {
      this.lootTimer = 22;
      const spot = this.freeSpot(0);
      this.dropLoot(spot.x, spot.y, 1);
    }
  }

  aliveCount() {
    let n = 0;
    for (const p of this.players.values()) if (!p.dead) n++;
    return n;
  }

  snapshot() {
    const players = [];
    for (const p of this.players.values()) {
      players.push({
        i: p.id, nick: p.nick, cls: p.cls, x: round(p.x), y: round(p.y), a: +p.ang.toFixed(2),
        hp: round(p.hp), mh: p.maxHp, d: p.downed > 0 ? 1 : 0, rv: +p.reviveT.toFixed(1),
        dead: p.dead ? 1 : 0, sc: round(p.score), k: p.kills, lv: p.level,
        xp: round(p.xp), xn: p.xpNeed, w: p.weapon, wl: p.weapons,
        am: { heavy: p.ammo.heavy, light: p.ammo.light, fuel: p.ammo.fuel },
        ab: +p.abilityCd.toFixed(1), abo: +p.abilityOn.toFixed(1),
        inf: round(p.inf), pr: p.perks, prot: p.spawnProt > 0 ? 1 : 0,
        of: p.offer ? p.offer.options : null,
        pm: Object.keys(p.permanent || {}).filter((k) => k !== 'xp2').length + ((p.permanent || {}).xp2 ? 1 : 0),
        dsh: p.dashT > 0 ? 1 : 0, imm: p.immune > 0 ? 1 : 0,
      });
    }
    const zombies = this.zombies.map((z) => ({
      i: z.id, x: round(z.x), y: round(z.y), h: round(z.hp), m: z.maxHp, t: z.type,
      b: z.burn > 0 ? 1 : 0, s: z.stun > 0 ? 1 : 0, r: z.r,
    }));
    const bullets = this.bullets.map((b) => ({ i: b.id, x: round(b.x), y: round(b.y), vx: round(b.vx), vy: round(b.vy), r: b.r, c: b.color }));
    return {
      t: +this.time.toFixed(2),
      wave: this.wave,
      phase: this.phase,
      nextIn: Math.max(0, +this.nextIn.toFixed(1)),
      left: this.zombies.length + this.spawnQueue.length,
      host: this.hostId,
      players, zombies, bullets,
      loot: this.loot.map((l) => ({ i: l.id, x: round(l.x), y: round(l.y), t: l.type })),
      turrets: this.turrets.map((t) => ({ i: t.id, x: round(t.x), y: round(t.y), u: +t.until.toFixed(1) })),
      mapW: W, mapH: H,
    };
  }

  playerOffer(id) {
    const p = this.players.get(id);
    return p ? p.offer : null;
  }
}

module.exports = {
  Game, circleFree, tileAt, lineClear, PR,
  generateMap: MAP.generateMap,
  TILE, COLS, ROWS, W, H, O: MAP.O, F: MAP.F,
};
