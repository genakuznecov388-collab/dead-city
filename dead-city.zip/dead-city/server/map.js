'use strict';
// Генерация карт: у каждой локации свой стиль — дороги, полы, препятствия, декор.
// map[]  — коды препятствий (0 = пусто, всё остальное — твёрдое)
// floor[] — визуальный тип пола (на проходимость не влияет)
// decor[] — необязательные объекты-украшения (рисуются под всеми)

const COLS = 48, ROWS = 36, TILE = 48;
const W = COLS * TILE, H = ROWS * TILE;

// Коды препятствий
const O = {
  EMPTY: 0, WALL: 1, HOUSE: 2, PILLAR: 3, CAR: 4, BARREL: 5, CRATE: 6,
  MACHINE: 7, TREE: 8, FENCE: 9, TENT: 10, KIOSK: 11, SANDBAG: 12, BED: 13,
};

// Типы пола
const F = {
  PLAIN: 0, ROAD_H: 1, ROAD_V: 2, ROAD_X: 3, SIDEWALK: 4, GRASS: 5,
  TILE: 6, CONCRETE: 7, SAND: 8, LINO: 9,
};

const SOLID = (code) => code !== 0;

const idx = (x, y) => y * COLS + x;
const inMap = (x, y) => x >= 0 && y >= 0 && x < COLS && y < ROWS;

function setRect(map, floor, x0, y0, w, h, code, floorKind) {
  for (let y = y0; y < y0 + h; y++) {
    for (let x = x0; x < x0 + w; x++) {
      if (!inMap(x, y)) continue;
      if (x === 0 || y === 0 || x === COLS - 1 || y === ROWS - 1) continue; // рамку не трогаем
      map[idx(x, y)] = code;
      if (floorKind !== undefined) floor[idx(x, y)] = floorKind;
    }
  }
}

function fillFloor(floor, kind) {
  floor.fill(kind);
}

// --- разметка дорог для «блочных» локаций ---------------------------------
function roadGrid(map, floor, rng, cfg) {
  const rows = [], cols = [];
  for (let y = cfg.rowStart; y < ROWS - 2; y += cfg.rowStep) { rows.push(y, y + 1); }
  for (let x = cfg.colStart; x < COLS - 2; x += cfg.colStep) { cols.push(x, x + 1); }
  const isRoadRow = new Set(rows), isRoadCol = new Set(cols);
  for (let y = 1; y < ROWS - 1; y++) {
    for (let x = 1; x < COLS - 1; x++) {
      const rr = isRoadRow.has(y), cc = isRoadCol.has(x);
      const i = idx(x, y);
      if (rr && cc) floor[i] = F.ROAD_X;
      else if (rr) floor[i] = F.ROAD_H;
      else if (cc) floor[i] = F.ROAD_V;
      else floor[i] = cfg.ground;
    }
  }
  // бордюры вдоль дорог
  for (let y = 1; y < ROWS - 1; y++) {
    for (let x = 1; x < COLS - 1; x++) {
      const i = idx(x, y);
      if (floor[i] !== cfg.ground) continue;
      const nearRoad = (isRoadRow.has(y - 1) || isRoadRow.has(y + 1) || isRoadCol.has(x - 1) || isRoadCol.has(x + 1));
      if (nearRoad) floor[i] = F.SIDEWALK;
    }
  }
  return { rows: [...isRoadRow], cols: [...isRoadCol] };
}

// --- локации ---------------------------------------------------------------
function layoutSuburb(map, floor, rng, loc) {
  fillFloor(floor, F.GRASS);
  const grid = roadGrid(map, floor, rng, { rowStart: 4, rowStep: 8, colStart: 5, colStep: 9, ground: F.GRASS });
  const onRoad = (x, y) => grid.rows.includes(y) || grid.cols.includes(x);

  // Дома внутри кварталов: аккуратные прямоугольники с двором, ничего «квадратного» на весь экран
  for (let by = 2; by < ROWS - 6; by += 8) {
    for (let bx = 2; bx < COLS - 6; bx += 9) {
      if (rng.next() < 0.18) continue; // пустырь
      const w = rng.int(4, 6), h = rng.int(3, 4);
      const x0 = bx + 1, y0 = by + 1;
      if (x0 + w >= COLS - 2 || y0 + h >= ROWS - 2) continue;
      if (onRoad(x0, y0) || onRoad(x0 + w, y0 + h)) continue;
      setRect(map, floor, x0, y0, w, h, O.HOUSE);
      // заборчик по периметру двора (с проходом)
      if (rng.chance(0.5)) {
        for (let x = x0 - 1; x <= x0 + w; x++) {
          if (rng.chance(0.25)) continue;
          if (inMap(x, y0 - 1) && !onRoad(x, y0 - 1) && floor[idx(x, y0 - 1)] !== F.SIDEWALK) map[idx(x, y0 - 1)] = O.FENCE;
        }
      }
    }
  }
  // редкие деревья и брошенные машины на дорогах
  for (let i = 0; i < 26; i++) {
    const x = rng.int(2, COLS - 3), y = rng.int(2, ROWS - 3);
    if (map[idx(x, y)] !== O.EMPTY) continue;
    if (onRoad(x, y)) { if (rng.chance(0.35)) map[idx(x, y)] = O.CAR; continue; }
    if (rng.chance(0.5)) map[idx(x, y)] = O.TREE;
  }
}

function layoutMall(map, floor, rng) {
  fillFloor(floor, F.TILE);
  // широкий центральный проход
  for (let x = 1; x < COLS - 1; x++) { floor[idx(x, 17)] = F.LINO; floor[idx(x, 18)] = F.LINO; }
  for (let y = 1; y < ROWS - 1; y++) { floor[idx(23, y)] = F.LINO; floor[idx(24, y)] = F.LINO; }
  // колонны по залу (круглые, а не стены)
  for (let y = 4; y < ROWS - 3; y += 6) {
    for (let x = 4; x < COLS - 3; x += 7) {
      if (map[idx(x, y)] === O.EMPTY) map[idx(x, y)] = O.PILLAR;
    }
  }
  // витрины магазинов вдоль верхней и нижней стены
  for (let x = 3; x < COLS - 3; x++) {
    if (rng.chance(0.25)) continue;
    if (inMap(x, 2) && map[idx(x, 2)] === O.EMPTY) { map[idx(x, 2)] = O.KIOSK; floor[idx(x, 2)] = F.CONCRETE; }
    if (inMap(x, ROWS - 3) && map[idx(x, ROWS - 3)] === O.EMPTY) { map[idx(x, ROWS - 3)] = O.KIOSK; floor[idx(x, ROWS - 3)] = F.CONCRETE; }
  }
  // тележки, ящики, лавки
  for (let i = 0; i < 34; i++) {
    const x = rng.int(2, COLS - 3), y = rng.int(5, ROWS - 6);
    if (map[idx(x, y)] !== O.EMPTY) continue;
    const r = rng.next();
    map[idx(x, y)] = r < 0.4 ? O.CRATE : r < 0.7 ? O.PILLAR : O.CAR;
  }
}

function layoutWards(map, floor, rng) {
  fillFloor(floor, F.LINO);
  // коридоры
  for (let x = 1; x < COLS - 1; x++) { floor[idx(x, 12)] = F.ROAD_H; floor[idx(x, 13)] = F.ROAD_H; floor[idx(x, 26)] = F.ROAD_H; floor[idx(x, 27)] = F.ROAD_H; }
  for (let y = 1; y < ROWS - 1; y++) { floor[idx(11, y)] = F.ROAD_V; floor[idx(12, y)] = F.ROAD_V; floor[idx(33, y)] = F.ROAD_V; floor[idx(34, y)] = F.ROAD_V; }
  // палаты: кровати и перегородки с проходами
  for (let by = 2; by < ROWS - 5; by += 14) {
    for (let bx = 2; bx < COLS - 5; bx += 11) {
      if (bx === 11 || bx === 33 || by === 12 || by === 26) continue;
      const w = 4, h = 3;
      if (bx + w >= COLS - 2 || by + h >= ROWS - 2) continue;
      if (rng.chance(0.3)) continue;
      setRect(map, floor, bx, by, w, h, O.WALL);
      // оставляем «дверь»
      const doorX = bx + rng.int(1, w - 2);
      map[idx(doorX, by + h - 1)] = O.EMPTY;
      floor[idx(doorX, by + h - 1)] = F.LINO;
      // кровати внутри
      for (let k = 0; k < 3; k++) {
        const x = bx + 1 + (k % 2), y = by + 1 + Math.floor(k / 2);
        if (map[idx(x, y)] === O.WALL) map[idx(x, y)] = O.BED;
      }
    }
  }
  // каталки и стойки в коридорах
  for (let i = 0; i < 30; i++) {
    const x = rng.int(2, COLS - 3), y = rng.int(2, ROWS - 3);
    if (map[idx(x, y)] !== O.EMPTY) continue;
    if (rng.chance(0.5)) map[idx(x, y)] = O.BED;
  }
}

function layoutMachines(map, floor, rng) {
  fillFloor(floor, F.CONCRETE);
  // технологические проходы (металлические настилы)
  for (let y = 6; y < ROWS - 3; y += 9) for (let x = 1; x < COLS - 1; x++) floor[idx(x, y)] = F.ROAD_H;
  // длинные линии станков с прогалами — не «квадраты»
  for (let y = 3; y < ROWS - 4; y += 6) {
    for (let x = 2; x < COLS - 3; x++) {
      if (x % 7 === 0 || x % 7 === 1) continue; // проход
      if (map[idx(x, y)] === O.EMPTY) map[idx(x, y)] = O.MACHINE;
      if (rng.chance(0.35) && map[idx(x, y + 1)] === O.EMPTY) map[idx(x, y + 1)] = O.MACHINE;
    }
  }
  // бочки, ящики, контейнеры
  for (let i = 0; i < 40; i++) {
    const x = rng.int(2, COLS - 3), y = rng.int(2, ROWS - 3);
    if (map[idx(x, y)] !== O.EMPTY) continue;
    const r = rng.next();
    map[idx(x, y)] = r < 0.5 ? O.BARREL : r < 0.8 ? O.CRATE : O.PILLAR;
  }
}

function layoutBase(map, floor, rng) {
  fillFloor(floor, F.SAND);
  // бетонный плац в центре
  setRect(map, floor, 14, 10, 20, 16, O.EMPTY, F.CONCRETE);
  // линии мешков с песком
  for (let i = 0; i < 16; i++) {
    const horiz = rng.chance(0.5);
    const len = rng.int(4, 9);
    const x0 = rng.int(2, COLS - 3 - (horiz ? len : 1));
    const y0 = rng.int(2, ROWS - 3 - (horiz ? 1 : len));
    for (let k = 0; k < len; k++) {
      const x = horiz ? x0 + k : x0, y = horiz ? y0 : y0 + k;
      if (!inMap(x, y) || map[idx(x, y)] !== O.EMPTY) continue;
      map[idx(x, y)] = O.SANDBAG;
    }
  }
  // палатки и техника
  for (let i = 0; i < 7; i++) {
    const x = rng.int(3, COLS - 6), y = rng.int(3, ROWS - 6);
    setRect(map, floor, x, y, 3, 2, O.TENT, F.SAND);
  }
  for (let i = 0; i < 12; i++) {
    const x = rng.int(2, COLS - 3), y = rng.int(2, ROWS - 3);
    if (map[idx(x, y)] !== O.EMPTY) continue;
    const r = rng.next();
    map[idx(x, y)] = r < 0.45 ? O.CAR : r < 0.8 ? O.CRATE : O.BARREL;
  }
}

const LAYOUTS = {
  blocks: layoutSuburb,
  hall: layoutMall,
  wards: layoutWards,
  machines: layoutMachines,
  base: layoutBase,
};

// --- декор (не влияет на проходимость) -------------------------------------
const DECOR_BY_LOC = {
  suburb: ['tree', 'bush', 'blood', 'crack', 'trash', 'cone'],
  mall: ['papers', 'cart', 'blood', 'puddle', 'sign', 'trash'],
  hospital: ['blood', 'papers', 'iv', 'crack', 'puddle'],
  factory: ['oil', 'cable', 'crack', 'sparks', 'trash'],
  military: ['tracks', 'sand', 'blood', 'trash', 'sparks'],
};

function makeDecor(loc, map, floor, rng) {
  const kinds = DECOR_BY_LOC[loc.id] || DECOR_BY_LOC.suburb;
  const decor = [];
  const count = Math.round(150 + loc.density * 420);
  for (let i = 0; i < count; i++) {
    const x = rng.int(1, COLS - 2), y = rng.int(1, ROWS - 2);
    if (map[idx(x, y)] !== O.EMPTY) continue;
    const t = rng.pick(kinds);
    decor.push({
      t,
      x: +(x * TILE + rng.float(6, TILE - 6)).toFixed(1),
      y: +(y * TILE + rng.float(6, TILE - 6)).toFixed(1),
      r: +rng.float(0, 6.28).toFixed(2),
      s: +rng.float(0.7, 1.6).toFixed(2),
    });
  }
  return decor;
}

// --- проверка связности -----------------------------------------------------
function reachableCount(map, sx, sy) {
  const seen = new Uint8Array(COLS * ROWS);
  const stack = [[sx, sy]];
  let open = 0;
  while (stack.length) {
    const [x, y] = stack.pop();
    if (!inMap(x, y)) continue;
    const i = idx(x, y);
    if (seen[i] || SOLID(map[i])) continue;
    seen[i] = 1; open++;
    stack.push([x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1]);
  }
  return open;
}

function generateMap(loc, rng) {
  const layout = LAYOUTS[loc.layout] || LAYOUTS.suburb;
  let best = null;

  for (let attempt = 0; attempt < 8; attempt++) {
    const map = new Uint8Array(COLS * ROWS);
    const floor = new Uint8Array(COLS * ROWS);
    for (let x = 0; x < COLS; x++) { map[idx(x, 0)] = O.WALL; map[idx(x, ROWS - 1)] = O.WALL; }
    for (let y = 0; y < ROWS; y++) { map[idx(0, y)] = O.WALL; map[idx(COLS - 1, y)] = O.WALL; }
    fillFloor(floor, F.PLAIN);

    layout(map, floor, rng, loc);

    // центр всегда свободен — там стартуют игроки
    for (let y = ROWS / 2 - 3; y <= ROWS / 2 + 3; y++) {
      for (let x = COLS / 2 - 3; x <= COLS / 2 + 3; x++) map[idx(x, y)] = O.EMPTY;
    }

    let floors = 0;
    for (let i = 0; i < map.length; i++) if (!SOLID(map[i])) floors++;
    const open = reachableCount(map, Math.floor(COLS / 2), Math.floor(ROWS / 2));
    const ratio = open / Math.max(1, floors);

    if (ratio > 0.72 && open > COLS * ROWS * 0.45) {
      return { map, floor, decor: makeDecor(loc, map, floor, rng) };
    }
    if (!best || open > best.open) best = { map, floor, open, ratio };
  }

  // не вышло — аварийный вариант: открытая площадка с редкими укрытиями
  const map = new Uint8Array(COLS * ROWS);
  const floor = new Uint8Array(COLS * ROWS);
  for (let x = 0; x < COLS; x++) { map[idx(x, 0)] = O.WALL; map[idx(x, ROWS - 1)] = O.WALL; }
  for (let y = 0; y < ROWS; y++) { map[idx(0, y)] = O.WALL; map[idx(COLS - 1, y)] = O.WALL; }
  fillFloor(floor, F.CONCRETE);
  for (let i = 0; i < 26; i++) {
    const x = rng.int(3, COLS - 4), y = rng.int(3, ROWS - 4);
    if (Math.abs(x - COLS / 2) < 4 && Math.abs(y - ROWS / 2) < 4) continue;
    map[idx(x, y)] = rng.pick([O.CRATE, O.BARREL, O.PILLAR, O.SANDBAG]);
  }
  return { map, floor, decor: makeDecor(loc, map, floor, rng) };
}

module.exports = { generateMap, COLS, ROWS, TILE, W, H, O, F, SOLID, reachableCount };
