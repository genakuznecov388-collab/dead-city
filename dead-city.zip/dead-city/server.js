'use strict';
// МЁРТВЫЙ ГОРОД — сервер: Express (статика+API) + Socket.IO (реальное время).
// Автор игры: Airon.
const path = require('path');
const http = require('http');
const express = require('express');
const { Server } = require('socket.io');

const C = require('./server/content');
const { Game, TILE, COLS, ROWS, W, H } = require('./server/game');
const store = require('./server/store');
const shop = require('./server/shop');
const { roomCode, newSeed } = require('./server/rng');

const PORT = process.env.PORT || 3000;
const MAX_ROOMS = 60;
// Токен админки: задаётся переменной окружения или генерируется при запуске.
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || require('crypto').randomBytes(9).toString('hex');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

app.use(express.json({ limit: '32kb' }));
app.use(express.static(path.join(__dirname, 'public'), { maxAge: '1h' }));

// --- API -------------------------------------------------------------------
app.get('/api/content', (req, res) => {
  res.json({
    author: 'Airon',
    game: 'МЁРТВЫЙ ГОРОД',
    classes: C.CLASSES,
    locations: C.LOCATIONS,
    tips: C.TIPS,
    perks: C.PERKS.map((p) => ({ id: p.id, name: p.name, desc: p.desc })),
    weapons: C.WEAPONS,
    zombies: C.ZOMBIES,
    maxRoom: C.MAX_ONLINE_ROOM,
  });
});

app.get('/api/leaderboard', (req, res) => {
  res.json({ top: store.top(50), total: store.totalRuns() });
});

// --- донат-магазин ---------------------------------------------------------
app.get('/api/shop', (req, res) => {
  res.json(shop.catalog());
});

app.get('/api/shop/my', (req, res) => {
  res.json(shop.playerState(String(req.query.nick || '')));
});

app.post('/api/shop/order', (req, res) => {
  const b = req.body || {};
  const nick = store.sanitizeNick(b.nick);
  if (!nick || nick === 'Безымянный') return res.status(400).json({ error: 'Укажи ник, который используешь в игре' });
  const kind = b.kind === 'xpx2' ? 'xpx2' : 'perk';
  const out = shop.createOrder({ nick: store.sanitizeNick(b.nick), kind, perkId: b.perkId, level: b.level });
  if (out.error) return res.status(400).json({ error: out.error });
  console.log(`[shop] заявка ${out.order.id}: ${out.order.nick} → ${out.order.kind === 'xpx2' ? 'двойной опыт' : out.order.perkId + ' ур.' + out.order.level} = ${out.order.amount}₽`);
  res.json({ ok: true, order: out.order });
});

// Админка владельца: подтверждение оплаты. Доступ по токену.
function adminOk(req) {
  const token = (req.query && req.query.token) || (req.body && req.body.token) || '';
  return token && token === ADMIN_TOKEN;
}

app.get('/admin', (req, res) => {
  if (!adminOk(req)) return res.status(403).send('<!doctype html><meta charset="utf-8"><body style="background:#0b0d10;color:#dfe6ee;font-family:sans-serif;padding:40px">Нужен токен: открой /admin?token=ВАШ_ТОКЕН<br><br>Токен печатается в логах сервера при запуске (строка «ADMIN TOKEN»).</body>');
  const orders = shop.listOrders();
  const rows = orders.map((o) => `<tr>
    <td>${o.created.slice(0, 16).replace('T', ' ')}</td>
    <td><b>${o.nick.replace(/[<>&]/g, '')}</b></td>
    <td>${o.kind === 'xpx2' ? 'Двойной опыт' : (o.perkId + ' · уровень ' + o.level)}</td>
    <td>${o.amount} ₽</td>
    <td>${o.status}</td>
    <td>${o.status === 'pending' ? `<form method="POST" action="/api/admin/order"><input type="hidden" name="token" value="${ADMIN_TOKEN}"><input type="hidden" name="id" value="${o.id}"><button name="action" value="paid" style="background:#2f6e3a;color:#fff;border:0;padding:6px 12px;border-radius:6px">Оплачено</button> <button name="action" value="rejected" style="background:#6e2f2f;color:#fff;border:0;padding:6px 12px;border-radius:6px">Отклонить</button></form>` : '—'}</td>
  </tr>`).join('');
  res.send(`<!doctype html><html lang="ru"><meta charset="utf-8"><title>Донат — заявки</title>
  <body style="background:#0b0d10;color:#dfe6ee;font-family:Segoe UI,sans-serif;padding:30px">
  <h1 style="margin-bottom:6px">Заявки на донаты</h1>
  <p style="color:#8b98a7">Подтверди оплату — перк включится игроку при следующем входе в бой.</p>
  <table style="border-collapse:collapse;width:100%;font-size:14px" border="1" cellpadding="8">
  <thead><tr style="color:#8b98a7"><th align="left">Когда</th><th align="left">Ник</th><th align="left">Товар</th><th align="left">Сумма</th><th align="left">Статус</th><th align="left">Действие</th></tr></thead>
  <tbody>${rows || '<tr><td colspan="6">Заявок пока нет</td></tr>'}</tbody></table></body></html>`);
});

app.post('/api/admin/order', (req, res) => {
  const token = (req.body && req.body.token) || (req.query && req.query.token) || '';
  if (token !== ADMIN_TOKEN) return res.status(403).send('Неверный токен');
  const out = shop.decide(String((req.body && req.body.id) || ''), String((req.body && req.body.action) || ''));
  if (out.error) return res.status(400).send(out.error);
  if (req.is('application/json')) return res.json({ ok: true, order: out.order });
  res.redirect('/admin?token=' + encodeURIComponent(ADMIN_TOKEN));
});

app.get('/api/stats', (req, res) => {
  res.json(statsPayload());
});

app.get('/healthz', (req, res) => res.json({ ok: true, uptime: process.uptime() }));

function statsPayload() {
  let inGame = 0;
  for (const g of rooms.values()) if (g.phase !== 'lobby') inGame += g.players.size;
  return {
    online: io.engine.clientsCount,
    rooms: rooms.size,
    inGame,
    runs: store.totalRuns(),
    uptime: Math.round(process.uptime()),
  };
}

// --- комнаты ---------------------------------------------------------------
/** @type {Map<string, Game>} */
const rooms = new Map();

// Кодируем тайловые слои строками base36: '0' — пусто, дальше коды препятствий/полов.
function encodeRows(arr) {
  const rows = [];
  for (let y = 0; y < ROWS; y++) {
    let s = '';
    for (let x = 0; x < COLS; x++) s += Number(arr[y * COLS + x]).toString(36);
    rows.push(s);
  }
  return rows;
}

function findOpenRoom() {
  for (const g of rooms.values()) {
    if (g.mode === 'coop' && g.players.size < g.maxPlayers && g.phase !== 'over') return g;
  }
  return null;
}

function createRoom(mode, location, maxPlayers) {
  if (rooms.size >= MAX_ROOMS) {
    // убираем самую старую пустую, иначе отказываем
    for (const [code, g] of rooms) {
      if (g.players.size === 0) { rooms.delete(code); break; }
    }
    if (rooms.size >= MAX_ROOMS) return null;
  }
  let code = roomCode();
  let guard = 0;
  while (rooms.has(code) && guard++ < 20) code = roomCode();
  const game = new Game({ code, location, seed: newSeed(), mode, maxPlayers });
  game.onDeath = (player, g) => {
    const res = store.addScore({
      nick: player.nick,
      score: player.score,
      kills: player.kills,
      wave: g.wave,
      level: player.level,
      cls: player.cls,
      location: g.location.id,
      mode: g.mode,
    });
    io.to(player.id).emit('dead', {
      score: player.score,
      kills: player.kills,
      wave: g.wave,
      level: player.level,
      rank: res.rank,
      inTop: res.inTop,
      location: g.location.name,
      cls: player.cls,
      mode: g.mode,
    });
    broadcastStats();
  };
  rooms.set(code, game);
  return game;
}

function roomInfo(g) {
  return {
    code: g.code,
    mode: g.mode,
    location: g.location.id,
    locationName: g.location.name,
    players: g.players.size,
    max: g.maxPlayers,
    wave: g.wave,
    phase: g.phase,
  };
}

function broadcastStats() {
  io.emit('stats', statsPayload());
  io.emit('rooms', [...rooms.values()].filter((g) => g.players.size < g.maxPlayers).map(roomInfo));
}

// --- сокеты ----------------------------------------------------------------
io.on('connection', (socket) => {
  socket.data.game = null;
  broadcastStats();

  socket.on('hello', (payload = {}) => {
    try {
      const nick = store.sanitizeNick(payload.nick);
      const cls = C.CLASSES[payload.cls] ? payload.cls : 'soldier';
      const location = C.LOCATIONS[payload.location] ? payload.location : 'suburb';
      const mode = payload.mode === 'coop' ? 'coop' : 'solo';
      const wantCode = typeof payload.code === 'string' ? payload.code.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 4) : '';

      if (socket.data.game) leaveRoom(socket);

      let game = null;
      if (mode === 'coop') {
        if (wantCode && rooms.has(wantCode)) {
          const g = rooms.get(wantCode);
          if (g.mode === 'coop' && g.players.size < g.maxPlayers && g.phase !== 'over') game = g;
          else { socket.emit('errorMsg', 'Комната заполнена или уже закрыта'); return; }
        } else if (wantCode) {
          socket.emit('errorMsg', 'Комната ' + wantCode + ' не найдена');
          return;
        } else {
          game = findOpenRoom() || createRoom('coop', location, C.MAX_ONLINE_ROOM);
        }
        if (!game) { socket.emit('errorMsg', 'Сервер перегружен, попробуйте позже'); return; }
      } else {
        game = createRoom('solo', location, 1);
        if (!game) { socket.emit('errorMsg', 'Сервер перегружен, попробуйте позже'); return; }
      }

      const player = game.addPlayer(socket.id, nick, cls, shop.permanentFor(nick));
      socket.data.game = game;
      socket.data.mode = mode;
      socket.join(game.code);

      socket.emit('joined', {
        youId: socket.id,
        code: game.code,
        mode: game.mode,
        location: game.location.id,
        locationName: game.location.name,
        maxPlayers: game.maxPlayers,
        tile: TILE,
        cols: COLS,
        rows: ROWS,
        width: W,
        height: H,
        map: encodeRows(game.map),
        floor: encodeRows(game.floor),
        decor: game.decor,
        permanent: player.permanent,
        isHost: game.hostId === socket.id,
        wave: game.wave,
        phase: game.phase,
      });

      if (mode === 'solo') game.start();
      io.to(game.code).emit('roomState', { code: game.code, players: [...game.players.values()].map((p) => ({ id: p.id, nick: p.nick, cls: p.cls, host: p.id === game.hostId })) });
      broadcastStats();
      console.log(`[room ${game.code}] + ${nick} (${cls}) ${mode}/${location} → ${game.players.size} чел.`);
    } catch (e) {
      console.error('[hello]', e);
      socket.emit('errorMsg', 'Ошибка входа в игру');
    }
  });

  socket.on('start', () => {
    const g = socket.data.game;
    if (!g) return;
    if (socket.id !== g.hostId) { socket.emit('errorMsg', 'Старт даёт только хозяин комнаты'); return; }
    if (g.start()) io.to(g.code).emit('started', { wave: g.wave });
  });

  socket.on('input', (inp) => {
    const g = socket.data.game;
    if (g) g.setInput(socket.id, inp);
  });

  socket.on('ability', () => {
    const g = socket.data.game;
    if (g) g.useAbility(socket.id);
  });

  socket.on('swap', (index) => {
    const g = socket.data.game;
    if (g) g.swapWeapon(socket.id, Math.max(0, Math.min(3, Number(index) | 0)));
  });

  socket.on('perk', (perkId) => {
    const g = socket.data.game;
    if (!g) return;
    if (!g.choosePerk(socket.id, String(perkId || ''))) {
      // неверный перк — тихо игнорируем
    }
  });

  socket.on('leave', () => leaveRoom(socket));

  socket.on('disconnect', () => { leaveRoom(socket); broadcastStats(); });
});

function leaveRoom(socket) {
  const g = socket.data.game;
  if (!g) return;
  const p = g.players.get(socket.id);
  if (p && !p.dead && g.phase !== 'lobby' && p.score > 0) {
    // игрок вышел из боя — фиксируем результат честно
    g.onDeath && g.onDeath(p, g);
  }
  g.removePlayer(socket.id);
  socket.leave(g.code);
  socket.data.game = null;
  io.to(g.code).emit('roomState', { code: g.code, players: [...g.players.values()].map((x) => ({ id: x.id, nick: x.nick, cls: x.cls, host: x.id === g.hostId })) });
  if (g.players.size === 0) { rooms.delete(g.code); console.log(`[room ${g.code}] закрыта`); }
  broadcastStats();
}

// --- игровой цикл 20 Гц ------------------------------------------------------
let last = Date.now();
setInterval(() => {
  const now = Date.now();
  const dt = now - last;
  last = now;
  for (const g of rooms.values()) {
    try {
      g.tick(dt);
      io.to(g.code).emit('snap', g.snapshot());
    } catch (e) {
      console.error(`[tick ${g.code}]`, e.message);
    }
  }
}, C.TICK_MS);

// счётчик онлайна — раз в 4 секунды всем
setInterval(broadcastStats, 4000);

server.listen(PORT, () => {
  console.log(`МЁРТВЫЙ ГОРОД — http://localhost:${PORT}  (игру создал Airon)`);
  console.log('ADMIN TOKEN (для страницы /admin?token=...): ' + ADMIN_TOKEN);
  console.log('Заявки на донаты: /admin?token=' + ADMIN_TOKEN);
});
